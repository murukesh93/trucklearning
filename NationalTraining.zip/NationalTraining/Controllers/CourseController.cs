﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NationalTraining.BL;
using NationalTraining.Data;
using NationalTraining.Models;

namespace NationalTraining.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class CourseController : ControllerBase
    {
        #region createCourse
        /// <summary>
        /// To create new course
        /// </summary>
        
        [HttpPost, Route("course")]
       
        public IActionResult createCourse(Course cr)
        {
            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                return Ok(CourseBL.createCourse(cr));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("createCourse", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });

            }
        }
        #endregion 

        #region updateCourse
        /// <summary>
        /// To update particular course
        /// </summary>
        [HttpPut, Route("course")]
        public IActionResult updateCourse([FromBody]UpdateCourse cr)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                return Ok(CourseBL.updateCourse(cr));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("updateCourse", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });

            }
        }
        #endregion

        #region deleteCourse
        /// <summary>
        /// To delete course
        /// </summary>
        [HttpDelete, Route("course")]
        public IActionResult deleteCourse([Required]int CourseId)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                else
                {
                    return Ok(CourseBL.deleteCourse(CourseId));
                   
                }
            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("deleteCourse", e.Message.ToString());

                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });
            }
        }
        #endregion

        #region listCourse
        /// <summary>
        ///list all course object
        /// </summary>
       //[Authorize(Roles = "Admin")]
        [HttpGet, Route("courses")]
        public IActionResult listCourse(int count, int offset,  string courseName, string createdName)
        {
            try
            {
               
                
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                return Ok(CourseBL.listCourse(count, offset, courseName,createdName));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("listCourse", e.Message);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });
            }
        }
        #endregion 

        #region selectCourse
        /// <summary>
        /// To  select course object
        /// </summary>
         //[Authorize(Roles = "End User")]
        [HttpGet, Route("course")]
        public IActionResult selectCourse([Required] int CourseId)
        {

            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                return Ok(CourseBL.selectCourseById(CourseId));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("selectCourse", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });
            }
        }
        #endregion

       

        #region getCourseReport
        /// <summary>
        ///list course report
        /// </summary>
        [HttpGet, Route("getCourseReport")]
        public IActionResult getCourseReport(int count, int offset, string courseName, string email, string firstName, string lastName, string phone,
            string courseStatus, string testStatus, int courseId, int userId, string courseType)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                return Ok(CourseBL.getCourseReport(count, offset, courseName, email, firstName, lastName, phone, courseStatus,
                    testStatus, courseId, userId, courseType));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("getCourseReport", e.Message);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });
            }
        }
        #endregion


    }
}