﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NationalTraining.Models;

namespace NationalTraining.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class TestController : ControllerBase
    {


        #region startTest
        /// <summary>
        /// To start test
        /// </summary>
        [HttpPost, Route("startTest")]
        public IActionResult startTest(StartTest st)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                return Ok(BL.TestBL.startTest(st));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("startTest", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });

            }
        }
        #endregion 

        #region saveAnswer
        /// <summary>
        /// To save answer
        /// </summary>
        [HttpPost, Route("saveAnswer")]
      
        public IActionResult saveAnswer(SaveAnswer st)
        {
            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                return Ok(BL.TestBL.saveAnswer(st));


            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("saveAnswer", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });

            }
        }
        #endregion

        #region getTestDetails
        /// <summary>
        /// To get Test Details
        /// </summary>
        [HttpGet, Route("getTestDetails")]
        public IActionResult getTestDetails([Required] int userId, [Required] int referenceId, string referenceType)
        {

            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                return Ok(BL.TestBL.getTestDetails(userId, referenceId, referenceType));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("getTestDetails", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });
            }
        }
        #endregion
        #region getTestDetailsForMobile
        /// <summary>
        /// To get Test Details For Mobile
        /// </summary>
        [HttpGet, Route("getTestDetailsForMobile")]
        public IActionResult getTestDetailsForMobile([Required] int userId, [Required] int referenceId, string referenceType)
        {

            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                return Ok(BL.TestBL.getTestDetailsForMobile(userId, referenceId, referenceType));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("getTestDetailsForMobile", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });
            }
        }
        #endregion

        #region getTestDetailsForMobile
        /// <summary>
        /// To get Test Details For Mobile
        /// </summary>
        [HttpGet, Route("getPracticeTestDetails")]
        public IActionResult getPracticeTestDetails([Required] int userId, [Required] int referenceId, string referenceType)
        {

            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                return Ok(BL.TestBL.getPracticeTestDetails(userId, referenceId, referenceType));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("getPracticeTestDetails", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });
            }
        }
        #endregion


        #region listCompletedTest
        /// <summary>
        ///list all the end user completed tests
        /// </summary>
        [HttpGet, Route("listCompletedCourseTest")]
        public IActionResult listCompletedCourseTest(int count, int offset, string courseName, int userId)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                return Ok(BL.TestBL.listCompletedCourseTest(count, offset, courseName, userId));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("listCompletedTest", e.Message);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });
            }
        }
        #endregion

        #region listCompletedChapterTest
        /// <summary>
        ///list all the end user completed tests
        /// </summary>
        [HttpGet, Route("listCompletedChapterTest")]
        public IActionResult listCompletedChapterTest(int count, int offset, string chapterName, int userId)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                return Ok(BL.TestBL.listCompletedChapterTest(count, offset, chapterName, userId));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("listCompletedTest", e.Message);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });
            }
        }
        #endregion
        #region saveTestDetails
        /// <summary>
        /// To save test details
        /// </summary>
        [HttpPost, Route("saveTestDetails")]
        
        public IActionResult saveTestDetails(TestDetails ts)
        {
            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                return Ok(BL.TestBL.saveTestDetails(ts));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("saveTestDetails", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });

            }
        }
        #endregion 

    }
}