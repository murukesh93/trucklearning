﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Net;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NationalTraining.BL;
using NationalTraining.Data;
using NationalTraining.Models;
 

namespace NationalTraining.Controllers
{
    [EnableCors("AllowAll")]
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class UserController : ControllerBase
    {
        #region createUser
        /// <summary>
        /// To create new User
        /// </summary>
        [HttpPost, Route("user")]
        [AllowAnonymous]
        public IActionResult createUser(user user)
        {
            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                
                Regex regexEmail = new Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$");
                System.Text.RegularExpressions.Match Email = regexEmail.Match(user.email);
                if(Email.Success)
                {
                    return Ok(UserBL.createUser(user));
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.BadRequest, new { status = "Error", message = "Please enter valid Email" });

                }

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("createUser", e.Message);
 
                    return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });
                
            }
        }
        #endregion 

        #region updateUser
        /// <summary>
        /// To update particular User
        /// </summary>
        [HttpPut, Route("user")]
        public IActionResult updateUser([FromBody]updateUser updateUser)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
               
                var result = UserBL.updateUser(updateUser);
               
                return StatusCode((int)HttpStatusCode.OK, result);
            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("updateUser", e.Message);
                 
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message }); 

            }
        }
        #endregion

        #region deleteUser
        /// <summary>
        /// To delete user by id
        /// </summary>
        [HttpDelete, Route("user")]
        public IActionResult deleteUser([Required]int userId)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                else
                {
                    var result = UserBL.deleteUser(userId);
                    
                    return StatusCode((int)HttpStatusCode.OK, result );
                }
            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("deleteUser", e.Message.ToString());

                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });
            }
        }
        #endregion

        #region listUser
        /// <summary>
        ///list all active Users
        /// </summary>
        [HttpGet, Route("users")]
        public IActionResult listUser(/*UserReport userReport*/int count, int offset, string firstName, string lastName, string email,
            string phone, string role, int stateId, string zipCode)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                return Ok(UserBL.listUser(count, offset, firstName, lastName, email, phone, role, stateId, zipCode));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("listUser", e.Message); 
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });
            }
        }
        #endregion

        #region selectUserById
        /// <summary>
        /// To  select UserById
        /// </summary>
        [HttpGet, Route("user")]
        public IActionResult selectUserById([Required] int userId)
        {

            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                return Ok(UserBL.selectUserById(userId));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("selectUserById", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });
            }
        }
        #endregion

       
        #region generateOTP
        /// <summary>
        /// To generateOTP for forgot password
        /// </summary>
        [HttpPut, Route("generateOTP")]
        [AllowAnonymous]
        public IActionResult generateOTP([FromBody]generateOTP otp)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                return Ok(UserBL.GenerateOTP(otp));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("generateOTP", e.Message.ToString());

                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });
            }
        }
        #endregion


        #region forgetPassword
        /// <summary>
        /// To update forgetPassword
        /// </summary>
        [HttpPut, Route("forgetPassword")]
        [AllowAnonymous]
        public IActionResult forgetPassword(forgetPassword forgotPassword)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                var result = UserBL.forgetPassword(forgotPassword);
              
                return StatusCode((int)HttpStatusCode.OK, result);
            }

            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("forgetPassword", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });
            }
        }
        #endregion forgetPassword      

        #region changePassword
        /// <summary>
        /// To change Password
        /// </summary>
        [HttpPut, Route("changePassword")]
        [AllowAnonymous]
        public IActionResult changePassword(changePassword changePassword)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                var result = UserBL.changePassword(changePassword);

                return StatusCode((int)HttpStatusCode.OK, result);
            }

            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("changePassword", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });
            }
        }
        #endregion forgetPassword      

        #region verifyOTP
        /// <summary>
        /// To verify OTP is valid or not
        /// </summary>
        [HttpPut, Route("verifyOTP")]
        [AllowAnonymous]
        public IActionResult verifyOTP(OTPverify verifyOTP)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                var result =UserBL.verifyOTP(verifyOTP);

                 return StatusCode((int)HttpStatusCode.OK, result);
                
            }

            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("verifyOTP", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });
            }
        }
        #endregion

       
        #region getEndUserDetails
        /// <summary>
        /// To select particular EndUserDetails
        /// </summary>
        [HttpGet, Route("getEndUserDetails")]
        public IActionResult getEndUserDetails([Required] int userId)
        {

            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                return Ok(UserBL.getEndUserDetails(userId));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("getEndUserDetails", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });
            }
        }
        #endregion

        #region getPaymentHistory
        /// <summary>
        ///list payment history details
        /// </summary>
        [HttpGet, Route("getPaymentHistory")]
        public IActionResult getPaymentHistory(int count, int offset, string courseName, string email, string firstName, string lastName, string phone,
            int userId, int courseId, string fromDate, string toDate)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                return Ok(UserBL.getPaymentHistory(count, offset, courseName, email, firstName, lastName, phone,userId,
                    courseId, fromDate, toDate));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("getPaymentHistory", e.Message);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });
            }
        }
        #endregion

        #region getState
        /// <summary>
        ///list all states
        /// </summary>
        [AllowAnonymous]
        [HttpGet, Route("getState")]
        public IActionResult getState()
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                return Ok(UserBL.getState());

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("getState", e.Message);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });
            }
        }
        #endregion
    }
}