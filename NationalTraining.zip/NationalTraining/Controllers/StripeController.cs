﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Stripe;
using NationalTraining.BL;
using NationalTraining.Models;

namespace NationalTraining.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class StripeController : ControllerBase
    {

        #region updateCustomer
        /// <summary>
        /// To updateCustomer
        /// </summary>
        [HttpPut, Route("updateCustomer")]
      
        public async Task<IActionResult> updateCustomer(updateCustomer objcard)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var result =  StripeBL.updateCustomer(objcard);


                return StatusCode((int)HttpStatusCode.OK, result);

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("updateCustomer", e.Message);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message.ToString() });
            }
        }
        #endregion 



        #region addCard
        /// <summary>
        /// To addCard
        /// </summary>
        [HttpPost, Route("addCard")]
       
        public async Task<IActionResult> addCard(addCard objcard)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var result = new StripeBL().addCard(objcard);


                return StatusCode((int)HttpStatusCode.OK, result);

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("addCard", e.Message);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message.ToString() });
            }
        }
        #endregion 

        #region deleteCard
        /// <summary>
        /// To deleteCard
        /// </summary>
        [HttpDelete, Route("deleteCard")]
     
        public IActionResult deleteCard(updateCustomer customer)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                var result = new StripeBL().deleteCard(customer);


                return StatusCode((int)HttpStatusCode.OK, result);

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("deleteCard", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message.ToString() });
            }
        }
        #endregion

        //#region listCardByUserId
        ///// <summary>
        ///// To listCardByUserId
        ///// </summary>
        //[HttpGet, Route("listCardByUserId")]
        //[AllowAnonymous]
        //public IActionResult listCardByUserId(string customerId)
        //{
        //    try
        //    {
        //        if (!ModelState.IsValid)
        //        {
        //            return BadRequest(ModelState);
        //        }
        //        var result = StripeBL.listCardByUserId(customerId);


        //        return StatusCode((int)HttpStatusCode.OK, result);

        //    }
        //    catch (Exception e)
        //    {

        //        return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message.ToString() });
        //    }
        //}
        //#endregion


        #region paymentMethod
        /// <summary>
        /// To paymentMethod
        /// </summary>
        [HttpPost, Route("paymentMethod")]
        
        public async Task<IActionResult> paymentMethod(Payment payment)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var result =  StripeBL.paymentMethod(payment);


                return StatusCode((int)HttpStatusCode.OK, result);

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("paymentMethod", e.Message);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message.ToString() });
            }
        }
        #endregion

        #region retrieveCustomer
        /// <summary>
        /// To retrieveCustomer
        /// </summary>
        [HttpPost, Route("retrieveCustomer")]
        
        public async Task<IActionResult> retrieveCustomer(StripeCustomer stripe)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                var result =  StripeBL.retrieveCustomer(stripe);


                return StatusCode((int)HttpStatusCode.OK, result);

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("retrieveCustomer", e.Message);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message.ToString() });
            }
        }
        #endregion


        #region purchaseCourse
        /// <summary>
        /// To purchase a course
        /// </summary>
        [HttpPost, Route("purchaseCourse")]
      
        public async Task<IActionResult> purchaseCourse(PurchaseCourse pc)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var result = new StripeBL().purchaseCourse(pc);


                return StatusCode((int)HttpStatusCode.OK, result);

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("purchaseCourse", e.Message);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { ErrorMessage = e.Message.ToString() });
            }
        }
        #endregion 

    }
}