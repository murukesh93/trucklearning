﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NationalTraining.BL;
using NationalTraining.Data;
using NationalTraining.Models;
using static NationalTraining.Data.Common;

namespace NationalTraining.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class UploadFileController : ControllerBase
    {


       

        #region uploadFile
        /// <summary>
        /// To uploadFile image for mobile
        /// </summary>
        [HttpPost, Route("uploadFile")]
        [AllowAnonymous]
        [DisableRequestSizeLimit]
        public IActionResult uploadFile(IFormFile formFile)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
              

                IFormFile myFile = Request.Form.Files.First();

               
                return Ok(new UploadFileBl().uploadFile(myFile).Result);
            }

            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("uploadFile", e.Message.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });
            }
        }

        #endregion

        //#region UploadFileBase64
        ///// <summary>
        ///// To uploadFile image for web
        ///// </summary>
        //[HttpPost, Route("UploadFileBase64")]
        //[AllowAnonymous]
        //public IActionResult UploadFileBase64([FromBody] UploadModel uploadModel)
        //{
        //    try
        //    {
        //        if (!ModelState.IsValid)
        //        {
        //            return BadRequest(ModelState);
        //        }
        //        IFormFile myFile = Request.Form.Files.First();
        //        return Ok(new UploadFileBl().uploadFile(myFile).Result);

        //    }
        //    catch (Exception e)
        //    {
        //        string SaveErrorLog = Data.Common.SaveErrorLog("UploadFileBase64", e.Message.ToString());
        //        return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });
        //    }
        //}
        //#endregion
    }
}