﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using NationalTraining.BL;

namespace NationalTraining.Controllers
{
    [EnableCors("AllowAll")]
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class DashBoardController : Controller
    {
        #region getAdminDashboard
        /// <summary>
        ///list all active Users
        /// </summary>
        [HttpGet, Route("adminDashBoard")]
        public IActionResult adminDashBoard()
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                return Ok(DashBoardBL.adminDashBoard());

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("adminDashBoard", e.Message);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });
            }
        }
        #endregion

        #region getUserDashboard
        /// <summary>
        /// To  get UserDashboard
        /// </summary>
        [HttpGet, Route("getUserDashboard")]
        public IActionResult getUserDashboard([Required] int userId)
        {

            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                return Ok(DashBoardBL.getUserDashboard(userId));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("getUserDashboard", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });
            }
        }
        #endregion
    }
}