﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NationalTraining.BL;
using NationalTraining.Models;

namespace NationalTraining.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class ChapterController : ControllerBase
    {

        #region saveChapter
        /// <summary>
        /// To create new chapter
        /// </summary>
        [HttpPost, Route("saveChapter")]
      
        public IActionResult saveChapter(Chapter ch)
        {
            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                return Ok(ChapterBL.saveChapter(ch));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("saveChapter", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });

            }
        }
        #endregion 

        #region updateChapter
        /// <summary>
        /// To update particular Chapter
        /// </summary>
        [HttpPut, Route("updateChapter")]
        public IActionResult updateChapter([FromBody]ChapterUpdate ch)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                return Ok(ChapterBL.updateChapter(ch));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("updateChapter", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });

            }
        }
        #endregion

        #region deleteChapter
        /// <summary>
        /// To delete Chapter
        /// </summary>
        [HttpDelete, Route("deleteChapter")]
        public IActionResult deleteChapter([Required]int chapterId)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                else
                {
                    return Ok(ChapterBL.deleteChapter(chapterId));

                }
            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("deleteChapter", e.Message.ToString());

                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });
            }
        }
        #endregion

        #region listChapter
        /// <summary>
        ///list all chapter based on particular course
        /// </summary>
        [HttpGet, Route("listChapter")]
        public IActionResult listChapter(int courseId)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                //var token = HttpContext.User.Claims.ToList();
                //var result = token[0].Value;


                return Ok(ChapterBL.listChapter(courseId));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("listChapter", e.Message);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });
            }
        }
        #endregion


        #region selectChapterById
        /// <summary>
        /// To  select particular chapter
        /// </summary>
        [HttpGet, Route("selectChapterById")]
        public IActionResult selectChapterById([Required] int chapterId)
        {

            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                return Ok(ChapterBL.selectChapterById(chapterId));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("selectChapterById", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });
            }
        }
        #endregion


    }
}