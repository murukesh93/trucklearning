﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NationalTraining.Models;
using NationalTraining.BL;
using System.Net;
using System.ComponentModel.DataAnnotations;

namespace NationalTraining.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class VehicleTypeController : ControllerBase
    {

        #region createVehicleType
        /// <summary>
        /// To create new Vehicle Type
        /// </summary>
        [HttpPost, Route("VehicleType")]
     
        public IActionResult createVehicleType(VehicleTypes veh)
        {
            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                return Ok(VehicleTypeBL.createVehicleType(veh));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("createVehicleType", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });

            }
        }
        #endregion 

        #region updateVehicleType
        /// <summary>
        /// To update particular Vehicle Type
        /// </summary>
        [HttpPut, Route("VehicleType")]
        public IActionResult updateVehicleType([FromBody]UpdateVehicleType veh)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                return Ok(VehicleTypeBL.updateVehicleType(veh));
              
            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("updateVehicleType", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });

            }
        }
        #endregion

        #region deleteVehicleType
        /// <summary>
        /// To delete vehicle Type
        /// </summary>
        [HttpDelete, Route("VehicleType")]
        public IActionResult deleteVehicleType([Required]int vehicleTypeId)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                else
                {
                    return Ok(VehicleTypeBL.deletevehicleType(vehicleTypeId));
                    
                }
            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("deleteUser", e.Message.ToString());

                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });
            }
        }
        #endregion

        #region listVehicleType
        /// <summary>
        ///list all vehicle type object
        /// </summary>
        [HttpGet, Route("VehicleTypes")]
        public IActionResult listVehicleType(int count, int offset, string VehicleType, string description, string vehicleName)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                return Ok(VehicleTypeBL.listvehicleType(count, offset,VehicleType,description, vehicleName));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("listVehicleType", e.Message);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });
            }
        }
        #endregion


        #region selectVehicleType
        /// <summary>
        /// To  select Vehicle Type
        /// </summary>
        [HttpGet, Route("VehicleType")]
        public IActionResult selectVehicleType([Required] int vehicleTypeId)
        {

            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                return Ok(VehicleTypeBL.selectvehicleTypeById(vehicleTypeId));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("selectVehicleType", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });
            }
        }
        #endregion

    }
}