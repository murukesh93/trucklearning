﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NationalTraining.BL;
using NationalTraining.Models;

namespace NationalTraining.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class WishlistController : ControllerBase
    {

        #region createWishlist
        /// <summary>
        /// To create new Wishlist  
        /// </summary>
        [HttpPost, Route("createWishList")]
      

        public IActionResult createWishList(Wishlist ws)
        {
            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                return Ok(WishlistBL.createWishlist(ws));

               
            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("createWishlist", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });

            }
        }
        #endregion  


        #region deleteWishlist
        /// <summary>
        /// To delete wishlist
        /// </summary>
        [HttpDelete, Route("deleteWishList")]
        public IActionResult deleteWishList([Required]int wishlistId)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                else
                {
                    return Ok(WishlistBL.deleteWishlist(wishlistId));
                   
                }
            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("deleteWishlist", e.Message.ToString());

                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });
            }
        }
        #endregion

        #region listwishList
        /// <summary>
        ///list all wishList of particular user
        /// </summary>
        [HttpGet, Route("listWishList")]
        public IActionResult listWishList(int count, int offset, string contentTitle, [Required]int userId)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                return Ok(WishlistBL.listwishList(count, offset, contentTitle, userId));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("listwishList", e.Message);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });
            }
        }
        #endregion

    }
}