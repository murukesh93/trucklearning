﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NationalTraining.BL;
using NationalTraining.Data;
using static NationalTraining.Models.Lesson;

namespace NationalTraining.Controllers
{

    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class LessonController : ControllerBase
    {
        #region saveLessons
        /// <summary>
        /// To save 
        /// Lesson
        /// </summary>
        [HttpPost, Route("Lesson")]

        public IActionResult createLesson(CreateLesson cl)
        {
            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                return Ok(LessonBL.createLesson(cl));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("createLesson", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });

            }
        }
        #endregion 

        //#region updateLesson
        ///// <summary>
        ///// To save 
        ///// Lesson
        ///// </summary>
        //[HttpPut, Route("Lesson")]

        //public IActionResult updateLesson(UpdateLesson ul)
        //{
        //    try
        //    {

        //        if (!ModelState.IsValid)
        //        {
        //            return BadRequest(ModelState);
        //        }

        //        return Ok(LessonBL.updateLesson(ul));

        //    }
        //    catch (Exception e)
        //    {
        //        string SaveErrorLog = Data.Common.SaveErrorLog("updateLesson", e.Message);

        //        return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });

        //    }
        //}
        //#endregion 
        #region deleteLesson
        /// <summary>
        /// To delete a Lesson
        /// </summary>
        [HttpDelete, Route("Lesson")]
        public IActionResult deleteLesson([Required]int lessonId)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                else
                {
                    return Ok(LessonBL.deleteLesson(lessonId));

                }
            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("deleteLesson", e.Message.ToString());

                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });
            }
        }
        #endregion

        #region listLessons
        /// <summary>
        ///list all  Lessons
        /// </summary>
        [HttpGet, Route("Lessons")]
        public IActionResult listLesson(int count, int offset, string lessonName, [Required]int chapterId)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                return Ok(LessonBL.listLesson(count, offset, lessonName, chapterId));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("listLesson", e.Message);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });
            }
        }
        #endregion 

        #region selectLesson
        /// <summary>
        /// To  select a Lesson
        /// </summary>
        [HttpGet, Route("Lesson")]
        public IActionResult selectLesson([Required] int lessonId)
        {

            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                return Ok(LessonBL.selectLesson(lessonId));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("selectLesson", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });
            }
        }
        #endregion

        #region selectChapterLessons
        /// <summary>
        ///list all corresponding media content for chapter
        /// </summary>
        [HttpGet, Route("selectChapterLessons")]
        public IActionResult selectChapterLessons([Required] int chapterId)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                return Ok(LessonBL.selectChapterLessons(chapterId));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("selectChapterLessons", e.Message);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });
            }
        }
        #endregion

        #region createCourseContent
        /// <summary>
        /// To create media content for particular course
        /// </summary>
        [HttpPost, Route("lessonContent")]

        public IActionResult createCourseContent(CourseContent con)
        {
            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                return Ok(LessonBL.createCourseContent(con));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("createVehicleType", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });

            }
        }
        #endregion 

        //#region updateCourseContent
        ///// <summary>
        ///// To update particular course content
        ///// </summary>
        //[HttpPut, Route("lessonContent")]
        //public IActionResult updateCourseContent(UpdateCourseContent con)
        //{
        //    try
        //    {
        //        if (!ModelState.IsValid)
        //        {
        //            return BadRequest(ModelState);
        //        }
        //        return Ok(LessonBL.updateCourseContent(con));

        //    }
        //    catch (Exception e)
        //    {
        //        string SaveErrorLog = Data.Common.SaveErrorLog("updateVehicleType", e.Message);

        //        return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });

        //    }
        //}
        //#endregion

        #region deleteCourseContent
        /// <summary>
        /// To delete particular media content
        /// </summary>
        [HttpDelete, Route("lessonContent")]
        public IActionResult deleteCourseContent([Required]int mediaContentId)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                else
                {
                    return Ok(LessonBL.deleteCourseContent(mediaContentId));

                }
            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("deleteCourseContent", e.Message.ToString());

                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });
            }
        }
        #endregion

        #region getMediaContent
        /// <summary>
        ///list all corresponding media content for chapter
        /// </summary>
        [HttpGet, Route("lessonContents")]
        public IActionResult getMediaContent([Required] int lessonId)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                return Ok(LessonBL.GetMediaContent(lessonId));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("getMediaContent", e.Message);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });
            }
        }
        #endregion

        #region selectMediaContent
        /// <summary>
        ///select MediaContent for particular id
        /// </summary>
        [HttpGet, Route("lessonContent")]
        public IActionResult selectMediaContent([Required] int mediaContentId)
        {
            try
            {
                if (!ModelState.IsValid)
                {

                    return BadRequest(ModelState);
                }

                return Ok(LessonBL.selectMediaContent(mediaContentId));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("selectMediaContent", e.Message);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });
            }
        }
        #endregion


        //#region getLesson
        ///// <summary>
        ///// To  select a Lesson
        ///// </summary>
        //[HttpGet, Route("getLesson")]
        //public IActionResult getLesson([Required] int lessonId)
        //{

        //    try
        //    {
        //        if (!ModelState.IsValid)
        //        {
        //            return BadRequest(ModelState);
        //        }
        //        return Ok(LessonBL.getLesson(lessonId));

        //    }
        //    catch (Exception e)
        //    {
        //        string SaveErrorLog = Data.Common.SaveErrorLog("getLesson", e.Message);

        //        return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });
        //    }
        //}
        //#endregion
    }
}