﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NationalTraining.BL;
using NationalTraining.Models;

namespace NationalTraining.Controllers
{
    [EnableCors("AllowAll")]
    [Route("api/[controller]")]
    [ApiController]
    
    public class LoginController : ControllerBase
    {
        #region login 
        /// <summary>
        /// 
        /// To Login
        /// </summary>
        // GET api/values
        [HttpPost, Route("login")]
        public IActionResult login([FromBody]login login)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                var result = LoginBL.login(login);

                if (result.status == "Success")
                {
                    return StatusCode((int)HttpStatusCode.OK, result);
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.Unauthorized, result);

                }
            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("login", e.Message);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });
            }
        }
        #endregion

        #region login 
        /// <summary>
        /// 
        ///Google authentication
        /// </summary>
        // GET api/values
        [HttpPost, Route("googleAuthentication")]
        public IActionResult googleAuthentication(ProviderLogin pl)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                var result = LoginBL.providerlogin(pl);

                if (result.status =="Success")
                {
                    return StatusCode((int)HttpStatusCode.OK, result);
                    
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.Unauthorized, result);

                }
            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("googleAuthentication", e.Message);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });
            }
        }
        #endregion


    }
}