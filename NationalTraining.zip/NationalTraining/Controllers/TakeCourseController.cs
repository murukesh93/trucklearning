﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NationalTraining.BL;
using NationalTraining.Data;
using NationalTraining.Models;

namespace NationalTraining.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class TakeCourseController : ControllerBase
    {
        #region startCourse
        /// <summary>
        /// To Start a course
        /// </summary>
        [HttpPost, Route("startCourse")]
       
        public IActionResult startCourse(StartCourse st)
        {
            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                return Ok(TakeCourseBL.startCourse(st));
               
            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("startCourse", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });

            }
        }
        #endregion 

        #region endCourse
        /// <summary>
        /// To end course
        /// </summary>
        [HttpPut, Route("endCourse")]
        public IActionResult endCourse(EndCourse en)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                return Ok(TakeCourseBL.endCourse (en));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("endCourse", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });

            }
        }
        #endregion 

        #region saveCourseLog
        /// <summary>
        /// To save course log
        /// </summary>
        [HttpPost, Route("saveCourseLog")]
     
        public IActionResult saveCourseLog(SaveCourseLog st)
        {
            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                return Ok(TakeCourseBL.saveCourseLog(st));

                
            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("saveCourseLog", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });

            }
        }
        #endregion

        #region Courses
        /// <summary>
        /// List all courses
        /// </summary>
        [HttpGet, Route("Courses")]
        public IActionResult Courses([Required]int userId, string search)
        {

            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                return Ok(TakeCourseBL.courses(userId, search));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("Courses", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });
            }
        }
        #endregion

        #region Course
        /// <summary>
        /// List particular course details
        /// </summary>
        [HttpGet, Route("Course")]
        public IActionResult Course([Required]int userId, [Required]int courseId)
        {

            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                return Ok(TakeCourseBL.course(userId, courseId));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("Course", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });
            }
        }
        #endregion
        #region takenChapter
        /// <summary>
        /// User taken Chapter
        /// </summary>
        [HttpGet, Route("takenChapter")]
        public IActionResult takenChapter([Required]int userId, [Required]int courseId)
        {

            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                return Ok(TakeCourseBL.takenChapter(userId, courseId));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("takenChapter", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });
            }
        }
        #endregion

        #region takenLesson
        /// <summary>
        /// User taken Lessons
        /// </summary>
        [HttpGet, Route("takenLesson")]
        public IActionResult takenLesson([Required]int userId, [Required]int chapterId, [Required]int courseDetailId)
        {

            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                return Ok(TakeCourseBL.takenLesson(userId, chapterId, courseDetailId));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("takenLesson", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });
            }
        }
        #endregion


        #region takenMediaContent
        /// <summary>
        /// User taken Lessons
        /// </summary>
        [HttpGet, Route("takenMediaContent")]
        public IActionResult takenMediaContent([Required]int userId, [Required]int lessonId, [Required] int courseDetailId)
        {

            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                return Ok(TakeCourseBL.takenMediaContent(userId, lessonId, courseDetailId));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("takenLesson", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });
            }
        }
        #endregion

        #region takenLessonForWeb
        /// <summary>
        /// User taken Lessons
        /// </summary>
        [HttpGet, Route("takenLessonForWeb")]
        public IActionResult takenLessonforWeb([Required]int userId, [Required]int courseId)
        {

            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                return Ok(TakeCourseBL.takenLessonforWeb(userId, courseId));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("takenLessonforWeb", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });
            }
        }
        #endregion

        #region userHistory
        /// <summary>
        /// User History details
        /// </summary>
        [HttpGet, Route("userHistory")]
        public IActionResult userHistory([Required]int userId)
        {

            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                return Ok(TakeCourseBL.userHistory(userId));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("userHistory", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });
            }
        }
        #endregion

          #region userMyHistory
        /// <summary>
        /// User History details
        /// </summary>
        [HttpGet, Route("userMyHistory")]
        public IActionResult userMyHistory([Required]int userId)
        {

            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                return Ok(TakeCourseBL.userMyHistory(userId));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("userMyHistory", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });
            }
        }
        #endregion
        #region userWishList
        /// <summary>
        /// User WishList details
        /// </summary>
        [HttpGet, Route("userWishList")]
        public IActionResult userWishList([Required]int userId)
        {

            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                return Ok(TakeCourseBL.userWishList(userId));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("userWishList", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });
            }
        }
        #endregion

        #region viewNotification
        /// <summary>
        /// To view Notification
        /// </summary>
        [HttpPost, Route("viewNotification")]

        public IActionResult viewNotification(ViewNotification vn)
        {
            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                return Ok(TakeCourseBL.viewNotification(vn));


            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("viewNotification", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });

            }
        }
        #endregion

    }
}