﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NationalTraining.BL;
using NationalTraining.Models;

namespace NationalTraining.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class QuestionController : ControllerBase
    {
        #region saveQuestion
        /// <summary>
        /// To save questions
        /// </summary>
        [HttpPost, Route("saveQuestion")]
      
        public IActionResult saveQuestion(Question qu)
        {
            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                return Ok(QuestionBL.saveQuestion(qu));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("saveQuestion", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });

            }
        }
        #endregion 


        #region deleteQuestion
        /// <summary>
        /// To delete a question
        /// </summary>
        [HttpDelete, Route("deleteQuestion")]
        public IActionResult deleteQuestion([Required]int questionId)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                else
                {
                    return Ok(QuestionBL.deleteQuestion(questionId));

                }
            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("deleteQuestion", e.Message.ToString());

                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });
            }
        }
        #endregion

        #region listCourseQuestion
        /// <summary>
        ///list all  questions
        /// </summary>
        [HttpGet, Route("listCourseQuestion")]
        public IActionResult listCourseQuestion(int count, int offset, string courseName,[Required] int courseId)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                return Ok(QuestionBL.listCourseQuestion(count, offset, courseName, courseId));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("listCourseQuestion", e.Message);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });
            }
        }
        #endregion

        #region listChapterQuestion
        /// <summary>
        ///list all  questions
        /// </summary>
        [HttpGet, Route("listChapterQuestion")]
        public IActionResult listChapterQuestion(int count, int offset, string chapterName, [Required] int chapterId)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                return Ok(QuestionBL.listChapterQuestion(count, offset, chapterName, chapterId));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("listChapterQuestion", e.Message);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });
            }
        }
        #endregion 

        #region selectQuestion
        /// <summary>
        /// To  select a question
        /// </summary>
        [HttpGet, Route("selectQuestion")]
        public IActionResult selectQuestion([Required] int questionId)
        {

            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                return Ok(QuestionBL.selectQuestion(questionId));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("selectQuestion", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });
            }
        }
        #endregion

        #region getQuestion
        /// <summary>
        /// To  select particular course contain questions
        /// </summary>
        [HttpGet, Route("getQuestion")]
        public IActionResult getQuestion([Required] int referenceId, [Required]string referenceType)
        {

            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                return Ok(QuestionBL.getQuestion(referenceId, referenceType));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("getQuestion", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });
            }
        }
        #endregion

        #region GetQuestionAutoComplete
        /// <summary>
        /// To  select particular course contain questions
        /// </summary>
        [HttpGet, Route("GetQuestionAutoComplete")]
        public IActionResult GetQuestionAutoComplete(int count, int offset, string search)
        {

            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                return Ok(QuestionBL.GetQuestionAutoComplete(count, offset,search));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("GetQuestionAutoComplete", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });
            }
        }
        #endregion
        #region GetTestCondition
        /// <summary>
        /// To  Get TestConditios
        /// </summary>
        [HttpGet, Route("GetTestCondition")]
        public IActionResult GetTestCondition([Required] int courseId)
        {

            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                return Ok(QuestionBL.GetTestCondition(courseId));

            }
            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("GetTestCondition", e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = e.Message });
            }
        }
        #endregion
    }
}