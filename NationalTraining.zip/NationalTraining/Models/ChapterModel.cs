﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace NationalTraining.Models
{
    public class Chapter
    {
      
       [Required]
        public int courseId { get; set; } 
        [Required]
        public string chapterContent { get; set; } 

    }

    public class ChapterUpdate
    {
        [Required]
        public int chapterId { get; set; }
        [Required]
        public int courseId { get; set; }
        [Required]
        public string chapterName { get; set; }
        [Required]
        public string chapterDescription { get; set; }
        [Required]
        public int chapterOrder { get; set; }


    }
}
