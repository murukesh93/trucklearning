﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace NationalTraining.Models
{


    public class login
    {
        [Required]
        public string email { get; set; }
        [Required]
        public string password { get; set; }
        public string timeZone { get; set; }

    }
    public class ProviderLogin
    {
        [Required]
        public string loginProviderKey { get; set; }
        [Required]
        public string email { get; set; }
        public string timeZone { get; set; }

    }

    public class forgetPassword
    {
        
        [Required]
        public string email { get; set; }
        [Required]
        public string password { get; set; }
    }
    public class changePassword
    {
        [Required]
        public int userId { get; set; }
        [Required]
        public string newPassword { get; set; }
        [Required]
        public string oldPassword { get; set; }
    }
    public class generateOTP
    {
        [Required]
        public string email { get; set; }
        //public string OTPValue { get; set; }
        public string otpType { get; set; }
    }
    public class OTPverify 
    {
        [Required]
        public string email { get; set; }
        [Required]
        public string oTPValue { get; set; }
        public string oTPType { get; set; }
    }
    public class user
    {
        //public int userId { get; set; }
        [Required]
        public string firstName { get; set; }
       
        public string lastName { get; set; }
        
        public string phone { get; set; }
        [Required]
        public string email { get; set; }
        [Required]
        public string password { get; set; }
        [DefaultValue(false)]
        public string profileImage { get; set; }

        [Required]
        public string role { get; set; }
        public int? stateId { get; set; }
        public string zipCode { get; set; }

    }
    public class updateUser
    {   [Required]
        public int userId { get; set; } 
        public string firstName { get; set; }
        public string lastName { get; set; }
        public string phone { get; set; }
        public string profileImage { get; set; }
        public string password { get; set; }
        public string role { get; set; }
        public int? stateId { get; set; }
        public string zipCode { get; set; }

    }

}
