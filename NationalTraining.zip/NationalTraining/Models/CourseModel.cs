﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace NationalTraining.Data
{
    public class Course
    {
        [Required]
        public string courseName { get; set; }
        public string courseDescription { get; set; }
       
        [Required]
        public int createdBy { get; set; }
       
        public string courseURL { get; set; }
        public bool isFeatured { get; set; }
        public string featuredStartDate { get; set; }
        public string featuredEndDate { get; set; }
        public bool isActive { get; set; }
        public string truckId { get; set; }
        public string courseType { get; set; }
        public decimal courseFee { get; set; }
    }
 
    public class UpdateCourse
    {
        [Required]
        public int courseId { get; set; }
        public string courseName { get; set; }
        public string courseDescription { get; set; }
        public string courseURL { get; set; }
        public bool isFeatured { get; set; }
        public string featuredStartDate { get; set; }
        public string featuredEndDate { get; set; }
        public bool isActive { get; set; }
        public string truckId { get; set; }
        public string courseType { get; set; }
        public decimal courseFee { get; set; }
        public int createdBy { get; set; }

    }
    public class CourseContent
    {
        [Required]
        public int lessonId { get; set; }  
        [Required]
        public List<MediaContentDetails> mediaContentDetails { get; set; } 

    }
    public class MediaContentDetails
    {
        [Required]
        public int mediaContentId { get; set; }
        [Required]
        public string contentTitle { get; set; }
        public string contentDescription { get; set; }
        public string contentURL { get; set; }
        public string contentType { get; set; }
        public int contentOrder { get; set; }
        public string duration { get; set; }


    }

    public class UpdateCourseContent
    {
        [Required]
        public int mediaContentId { get; set; }
        public string contentTitle { get; set; }
        public string contentDescription { get; set; }
        public string contentURL { get; set; }
        public string contentType { get; set; }
        public int contentOrder { get; set; }
        public string duration { get; set; }

    }


}
