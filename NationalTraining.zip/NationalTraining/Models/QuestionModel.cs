﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace NationalTraining.Models
{
    public class Question
    {   [Required] 
        public int referenceId { get; set; } 
        [Required]
        public int createdBy { get; set; }
        [Required]
        public string questionContent { get; set; }

        //public  List<questionContent> questionContent { get; set; }
        public string referenceType { get; set; }


    }

    public class questionContent
    {
        public int questionId { get; set; }
        [Required]
        public string questionLable { get; set; }
        [Required]
        public string questionType { get; set; }
        public string questionOptions { get; set; }
        [Required]
        public string answer { get; set; }
        public string questionDescription { get; set; }
        [Required]
        public int sortOrder { get; set; }


    }




}
