﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace NationalTraining.Models
{
    public class StartTest
   {
    [Required]
    public int referenceId { get; set; }
     [Required]
    public string referenceType { get; set; }

    [Required]
    public int userId { get; set; }
}

    public class TestDetails
    {
        [Required]
        public int referenceId { get; set; }
        [Required]
        public decimal passScore { get; set; }
        [Required]
        public string referenceType { get; set; }


    }
    public class SaveAnswer
{
    [Required]
    public int referenceId { get; set; }
    [Required]
    public string referenceType { get; set; }
    [Required]
    public int userId { get; set; }
    [Required]
    public int answerDetailId { get; set; }
    [Required]
    public string answer { get; set; }
    [Required]
    public decimal testScore { get; set; }
    [Required]
    public string testResult { get; set; }
        

    }

}
