﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace NationalTraining.Models
{
    public class VehicleTypes
    {  [Required]
        public string vehicleType { get; set; }
        public string vehicleName { get; set; }
        public string description { get; set; }
        public string vehicleImage { get; set; }

    }
    public class UpdateVehicleType
    {
        [Required]
        public int vehicleTypeId { get; set; }
        public string vehicleName { get; set; }
        public string vehicleType { get; set; }
        public string description { get; set; }
        public string vehicleImage { get; set; }

    }

}
