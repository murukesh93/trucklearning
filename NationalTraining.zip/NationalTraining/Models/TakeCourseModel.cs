﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace NationalTraining.Models
{
    public class StartCourse
        {
            [Required]
            public int courseId { get; set; }
            [Required]
            public int userId { get; set; }
        }
    public class EndCourse
        {
            [Required]
            public int courseId { get; set; }
            [Required]
            public int userId { get; set; }
            [Required]
            public int courseDetailId { get; set; }

        }
    public class SaveCourseLog
    {
        [Required]
        public int courseDetailId { get; set; }
        [Required]
        public int mediaContentId { get; set; }
        [Required]
        public string contentStatus { get; set; } 

        public string progressDetails { get; set; }

    }
    public class CreatePracticeTest
    {
        [Required]
        public int courseId { get; set; }
        [Required]
        public string question { get; set; }
        [Required]
        public string answerA { get; set; }
        [Required]
        public string answerB { get; set; }
        [Required]
        public string answerC { get; set; }
        [Required]
        public string answerD { get; set; }
        [Required]
        public string correctAnswer { get; set; }
        [Required]
        public string explanation { get; set; }
        [Required]
        public int sortOrder { get; set; }
       


    }
    public class UpdatePracticeTest
    {
        [Required]
        public int practiceId { get; set; }
        public int courseId { get; set; }
        public string question { get; set; }
        public string answerA { get; set; }
        public string answerB { get; set; }
        public string answerC { get; set; }
        public string answerD { get; set; }
        public string correctAnswer { get; set; }
        public string explanation { get; set; }
        public int sortOrder { get; set; }

    }

    public class ViewNotification
    {
        [Required]
        public int id { get; set; }
        [Required]
        public int userId { get; set; }
        [Required]
        public string type { get; set; }


    }


}
