﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace NationalTraining.Models
{
    public class Lesson
    {
        public class CreateLesson
        {
            [Required]
            public int chapterId { get; set; }
            public List<LessonDetails> lessonDetails { get; set; }
        }

        public class LessonDetails
        {
            [Required]
            public int lessonId{ get; set; }

            [Required]
            public string lessonName { get; set; }
            public string lessonDescription { get; set; }
            public int lessonOrder { get; set; }
            
        }
        public class UpdateLesson
        {
            [Required]
            public int lessonId { get; set; }
            public int chapterId { get; set; }
            public string lessonName { get; set; }
            public string lessonDescription { get; set; }
            public int lessonOrder { get; set; }
        }
    }
}
