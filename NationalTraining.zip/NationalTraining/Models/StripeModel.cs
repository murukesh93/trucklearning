﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace NationalTraining.Models
{
    public class StripeCustomer
    {
        [Required]
        public string customerId { get; set; }
    }

    public class addCard
    {
        [Required]
        public string customerId { get; set; }
        [Required]
        public string token { get; set; }

    }
    public class updateCustomer
    {
        [Required]
        public string customerId { get; set; }
        [Required]
        public string cardId { get; set; }

    }


        public class Payment
        {
            [Required]
            public string customerId { get; set; }
            [Required]
            public Double amount { get; set; }
            public string description { get; set; }
            public string source { get; set; }

    }

    public class PurchaseCourse
    {
        [Required]
        public int userId { get; set; }
        [Required]
        public string customerId { get; set; }
        public string source { get; set; }
        [Required]
        public int courseId { get; set; }
        [Required]
        public decimal amount { get; set; }

    }
}
