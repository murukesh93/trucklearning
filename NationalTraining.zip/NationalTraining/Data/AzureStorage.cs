﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.Azure.Storage.DataMovement;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;

namespace NationalTraining.Data
{
    public class AzureStorage
    {

        public static async Task<string> UploadImages(long length, IFormFile formFile, string myFileName)
        {
            string uri = "";


            var accountKey = Common.GetConfigValue("StorageAccount");
            var folderName = Common.GetConfigValue("StorageImagesFolderName");
            string storageAccountConnectionString = accountKey;
            CloudStorageAccount StorageAccount = CloudStorageAccount.Parse(storageAccountConnectionString);
            CloudBlobClient BlobClient = StorageAccount.CreateCloudBlobClient();
            CloudBlobContainer Container = BlobClient.GetContainerReference(folderName);
            //await Container.CreateIfNotExistsAsync();
            CloudBlockBlob blob = Container.GetBlockBlobReference(myFileName);
            HashSet<string> blocklist = new HashSet<string>();
            var file = formFile;
            const int pageSizeInBytes = 15485760;
            long prevLastByte = 0;
            long bytesRemain = length;

            //byte[] bytes= myFileContent;


            byte[] bytes;

            using (MemoryStream ms = new MemoryStream())
            {
                var fileStream = file.OpenReadStream();
                await fileStream.CopyToAsync(ms);
                bytes = ms.ToArray();
            }
            Data.Common.SaveErrorLog("uploadFileBL", "data2");



            var writeOnlyPolicy = new SharedAccessBlobPolicy()
            {
                SharedAccessStartTime = DateTime.Now,
                SharedAccessExpiryTime = DateTime.Now.AddHours(2),
                Permissions = SharedAccessBlobPermissions.Write
            };

            blob.GetSharedAccessSignature(writeOnlyPolicy);
            // Upload each piece
            do
            {
                long bytesToCopy = Math.Min(bytesRemain, pageSizeInBytes);
                byte[] bytesToSend = new byte[bytesToCopy];

                Array.Copy(bytes, prevLastByte, bytesToSend, 0, bytesToCopy);
                prevLastByte += bytesToCopy;
                bytesRemain -= bytesToCopy;

                //create blockId
                string blockId = Guid.NewGuid().ToString();
                string base64BlockId = Convert.ToBase64String(Encoding.UTF8.GetBytes(blockId));

                await blob.PutBlockAsync(
                    base64BlockId,
                    new MemoryStream(bytesToSend, true),
                    null
                    );

                blocklist.Add(base64BlockId);

            } while (bytesRemain > 0);

            //post blocklist
            await blob.PutBlockListAsync(blocklist);

            uri = Convert.ToString(blob.Uri);


            return uri;

        }

       
        public static async Task<string> UploadImage(IFormFile formFile, string DocumentName)
        {
            string uri = "";


            try
            {
                var accountKey = Common.GetConfigValue("StorageAccount");
                var folderName = Common.GetConfigValue("StorageImagesFolderName");

                CloudStorageAccount cloudStorageAccount = CloudStorageAccount.Parse(accountKey);
                CloudBlobClient cloudBlobClient = cloudStorageAccount.CreateCloudBlobClient();
                CloudBlobContainer cloudBlobContainer = cloudBlobClient.GetContainerReference(folderName);
                CloudBlockBlob cloudBlockBlob = cloudBlobContainer.GetBlockBlobReference(DocumentName);


                var writeOnlyPolicy = new SharedAccessBlobPolicy()
                {
                    SharedAccessStartTime = DateTime.Now,
                    SharedAccessExpiryTime = DateTime.Now.AddHours(2),
                    Permissions = SharedAccessBlobPermissions.Write
                };

                //var sas = cloudBlobContainer.GetSharedAccessSignature(writeOnlyPolicy);
                cloudBlockBlob.GetSharedAccessSignature(writeOnlyPolicy);

                //byte[] byteArray = Encoding.ASCII.GetBytes(DocumentBytes);
                //MemoryStream stream = new MemoryStream(byteArray);

                using (var stream = formFile.OpenReadStream())
                {
                    await cloudBlockBlob.UploadFromStreamAsync(stream);
                }

                //Stream fileStream = new MemoryStream(file);
                //await cloudBlockBlob.UploadFromStreamAsync(fileStream);
                //var fileStream = file.OpenReadStream();
                ////Stream fileStream = new MemoryStream(fileStram);
                //await cloudBlockBlob.UploadFromStreamAsync(fileStream);
                uri = Convert.ToString(cloudBlockBlob.Uri);
                return uri;
            }

            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("AzureStorage", e.Message.ToString());

                throw e;
            }

        }
    }
}
