﻿using Microsoft.ApplicationBlocks.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace NationalTraining.Data
{
    public class DbConnection
    {
        #region Get Data in DataTable
        public static DataTable GetData(string procedureName)
        {
            try
            {
                string ConnectionString = Common.GetConnectionString("ConnectionString", "DefaultConnection");
                //Execute the query
                using (DataTable dt = SqlHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, procedureName).Tables[0])
                {
                    return dt;
                }
            }
            catch (Exception e)
            {
                throw e;
            }

        }
        #endregion

        #region Get Data in Dataset
        public static DataSet GetDataSet(string procedureName)
        {
            try
            {
                string ConnectionString = Common.GetConnectionString("ConnectionString", "DefaultConnection");
                //Execute the query
                using (DataSet dt = SqlHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, procedureName))
                {
                    return dt;
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }
        #endregion

        #region GetData By ID
        public static DataTable GetDataById(string procedureName, List<SqlParameter> parameters)
        {
            try
            {
                string ConnectionString = Common.GetConnectionString("ConnectionString", "DefaultConnection");

                //Execute the query
                using (DataTable dt = SqlHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, procedureName, parameters.ToArray()).Tables[0])
                {
                    return dt;
                }
            }
            catch (Exception e)
            {
                throw e;
            }

        }
        #endregion

        #region ExecuteScalar
        public static string ExecuteScalar(string procedureName, List<SqlParameter> parameters)
        {
            try
            {
                string ConnectionString = Common.GetConnectionString("ConnectionString", "DefaultConnection");

                string rowsAffected = SqlHelper.ExecuteScalar(ConnectionString, CommandType.StoredProcedure, procedureName, parameters.ToArray()).ToString();
                return rowsAffected;

            }
            catch (Exception e)
            {
                throw e;
            }
        }
        #endregion

        #region Delete 
        public static int Delete(string procedureName, List<SqlParameter> parameters)
        {
            try
            {
                string ConnectionString = Common.GetConnectionString("ConnectionString", "DefaultConnection");

                int RowsAffected = SqlHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, procedureName, parameters.ToArray());
                return RowsAffected;
               
            }
            catch (Exception e)
            {
                throw e;
            }
        }
        #endregion

        #region Save data
        public static DataSet save(string procedureName, List<SqlParameter> parameters)
        {
            try
            {
                string connectionstring = Common.GetConnectionString("ConnectionString", "DefaultConnection");
                using (DataSet dt = SqlHelper.ExecuteDataset(connectionstring, CommandType.StoredProcedure, procedureName, parameters.ToArray()))
                {
                    return dt;
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }
        #endregion

    }
}
