﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using NationalTraining.Data;
using NationalTraining.Models;
using System.Text.RegularExpressions;
//using static NationalTraining.Data.Common;


namespace NationalTraining.BL
{
    public class UploadFileBl :ControllerBase
    {
        #region uploadFile
        public async Task<dynamic> uploadFile(IFormFile formFile)
        {
            try
            {
                string myFileName = null;

                myFileName = formFile.FileName;
                string Exceptsymbols = Regex.Replace(myFileName, @"[^.0-9a-zA-Z]+", "");
                string[] strFilename = Exceptsymbols.Split('.');
                myFileName = strFilename[0] + "_" + DateTime.Now.ToString("dd'-'MM'-'yyyy'-'HH'-'mm'-'ss") + "." + strFilename[1];

               string fileurl = Data.AzureStorage.UploadImage(formFile, myFileName).Result;

                return new { status = "Success", data = fileurl };
               
            }

            catch (Exception e)
            {
                string SaveErrorLog = Data.Common.SaveErrorLog("uploadFileBLcatch", e.Message.ToString());

                throw e;
            }
        }

        #endregion
       
        //#region UploadFileBase64
        //public async Task<dynamic> UploadFileBase64([FromBody] UploadModel uploadModel)
        //{
        //    try
        //    {
        //        var imageDataByteArray = Convert.FromBase64String(uploadModel.file);

        //        string myFileName = uploadModel.fileName;
        //        byte[] myFileContent = imageDataByteArray;

        //        string fileurl = Common.CreateMediaItem(myFileContent, myFileName);
        //        return new { status = "Success", data = fileurl };

        //    }
        //    catch (Exception e)
        //    {
        //        throw e;
        //    }
        //}
        //#endregion
    }
}
