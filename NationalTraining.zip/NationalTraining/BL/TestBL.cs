﻿using NationalTraining.Data;
using NationalTraining.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace NationalTraining.BL
{
    public class TestBL
    {
        public static dynamic startTest(StartTest ed)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@referenceId", ed.referenceId));
                parameters.Add(new SqlParameter("@referenceType", ed.referenceType));
                parameters.Add(new SqlParameter("@userId", ed.userId));


                DataTable dt = DbConnection.GetDataById("spStartTest", parameters);

                 
                int answerDetailId = (int?)dt.Rows[0]["answerDetailId"] ?? 0;
                decimal passScore = (decimal?)dt.Rows[0]["passScore"] ?? 0;
                if (answerDetailId > 0)
                {
                    return new { status = "Success", message = "Record saved successfully", answerDetailId= answerDetailId, passScore= passScore };

                }
                else
                {
                    return new { status = "Error", message = "Error occured start test" };
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic saveAnswer(SaveAnswer sa)
        {
            try
            {

                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@answer", sa.answer));
                parameters.Add(new SqlParameter("@answerDetailId", sa.answerDetailId));
                parameters.Add(new SqlParameter("@referenceId", sa.referenceId));
                parameters.Add(new SqlParameter("@referenceType", sa.referenceType));
                parameters.Add(new SqlParameter("@testResult", sa.testResult));
                parameters.Add(new SqlParameter("@testScore", sa.testScore));
                parameters.Add(new SqlParameter("@userId", sa.userId));

                DataTable dt = DbConnection.GetDataById("spSaveAnswer", parameters); 
                string message = dt.Rows[0]["errorMessage"].ToString();
                if (message == "Success")
                {
                    return new { status = "Success", message = "Record saved successfully" };

                }
                else
                {
                    return new { status = "Error", message = dt.Rows[0]["errorMessage"].ToString() };
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }
         
        public static dynamic getTestDetails(int userId, int referenceId, string referenceType)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                dynamic user = new System.Dynamic.ExpandoObject();
                parameters.Add(new SqlParameter("@userId", userId > 0 ? userId : 0));
                parameters.Add(new SqlParameter("@referenceId", referenceId > 0 ? referenceId : 0));
                parameters.Add(new SqlParameter("@referenceType", referenceType));

                DataSet ds = DbConnection.save("spGetTest", parameters); 


                if (ds.Tables[0].Rows.Count > 0 )
                {

                    //dynamic courseobj = new System.Dynamic.ExpandoObject();
                    //courseobj.courseId = (int?)ds.Tables[0].Rows[0]["courseId"] ?? 0;
                    //courseobj.courseName = ds.Tables[0].Rows[0]["courseName"].ToString() ?? "";
                    //courseobj.testStartDate = ds.Tables[0].Rows[0]["testStartDate"].ToString() ?? "";
                    //courseobj.testEndDate = ds.Tables[0].Rows[0]["testEndDate"].ToString() ?? "";
                    //courseobj.testScore = (int?)ds.Tables[0].Rows[0]["testScore"] ?? 0;
                    //courseobj.isTest = (bool?)ds.Tables[0].Rows[0]["isTest"] ?? false;

                    return new { status = "Success", data = ds.Tables[0] };

                }
                else
                {
                    return new { status = "Success", data = ds.Tables[0], message = "No record found" };

                }
                 
            }
            catch (Exception e)
            {
                throw e;
            }
        }


        public static dynamic getTestDetailsForMobile(int userId, int referenceId, string referenceType)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                dynamic user = new System.Dynamic.ExpandoObject();
                parameters.Add(new SqlParameter("@userId", userId > 0 ? userId : 0));
                parameters.Add(new SqlParameter("@referenceId", referenceId > 0 ? referenceId : 0));
                parameters.Add(new SqlParameter("@referenceType", referenceType));

                DataSet ds = DbConnection.save("spGetTestMobile", parameters);


                if (ds.Tables[0].Rows.Count > 0)
                {
                    return new { status = "Success", data = ds.Tables[0] };
                }
                else
                {
                    return new { status = "Success", data = ds.Tables[0], message = "No record found" };
                }

            }
            catch (Exception e)
            {
                throw e;
            }
        }


        public static dynamic getPracticeTestDetails(int userId, int referenceId, string referenceType)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                dynamic user = new System.Dynamic.ExpandoObject();
                parameters.Add(new SqlParameter("@userId", userId > 0 ? userId : 0));
                parameters.Add(new SqlParameter("@referenceId", referenceId > 0 ? referenceId : 0));
                parameters.Add(new SqlParameter("@referenceType", referenceType));

                DataSet ds = DbConnection.save("spGetPracticeTestDetails", parameters);



              return new { status = "Success", data = new {name= "Practice Test",status= ds.Tables[2].Rows[0]["status"] ,
                        totalQuestions = ds.Tables[0].Rows[0]["totalQuestions"], 
                        sortOrder = ds.Tables[1].Rows[0]["sortOrder"],
                        isChanged= ds.Tables[3].Rows[0]["isChanged"]
              } };
               
                //else
                //{
                //    return new { status = "Success", data = ds.Tables[0], message = "No record found" };
                //}

            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic listCompletedCourseTest(int count, int offset, string courseName, int userId )
        {
            List<dynamic> courseList = new List<dynamic>();
            try
            {

                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@count", count > 0 ? count : 10));
                parameters.Add(new SqlParameter("@Offset", offset > 0 ? offset : 0));
                parameters.Add(new SqlParameter("@courseName", courseName));
                parameters.Add(new SqlParameter("@userId", userId));

                DataSet ds = DbConnection.save("spGetCompletedTestCourse", parameters);
                DataTable dt = ds.Tables[1];
                DataTable dt1 = ds.Tables[0];

                if (dt.Rows.Count > 0)
                {
                   
                    return new { status = "Success", data = dt, count = (int?)dt1.Rows[0][0] ?? 0 };

                }
                else
                {
                    return new { status = "Success", data = courseList, message = "No record found" };

                }

            }

            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic listCompletedChapterTest(int count, int offset, string chapterName, int userId)
        {
            List<dynamic> courseList = new List<dynamic>();
            try
            {

                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@count", count > 0 ? count : 10));
                parameters.Add(new SqlParameter("@Offset", offset > 0 ? offset : 0));
                parameters.Add(new SqlParameter("@chapterName", chapterName));
                parameters.Add(new SqlParameter("@userId", userId));

                DataSet ds = DbConnection.save("spGetCompletedTestChapter", parameters);
                DataTable dt = ds.Tables[1];
                DataTable dt1 = ds.Tables[0];

                if (dt.Rows.Count > 0)
                {

                    return new { status = "Success", data = dt, count = (int?)dt1.Rows[0][0] ?? 0 };

                }
                else
                {
                    return new { status = "Success", data = courseList, message = "No record found" };

                }

            }

            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic saveTestDetails(TestDetails ts)
        {
            try
            {

                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@referenceId", ts.referenceId));
                parameters.Add(new SqlParameter("@passScore", ts.passScore));
                parameters.Add(new SqlParameter("@referenceType", ts.referenceType));

                DataTable dt = DbConnection.GetDataById("spSaveTestDetails", parameters);

                if (dt.Rows[0]["errorMessage"].ToString() == "Success")
                {
                    return new { status = "Success", message = "Record saved successfully" };
                }
                else
                {
                    return new { status = "Error", message = "Error in save test details" };
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }
    }
}
