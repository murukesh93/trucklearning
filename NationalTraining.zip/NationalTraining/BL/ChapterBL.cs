﻿using NationalTraining.Data;
using NationalTraining.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace NationalTraining.BL
{
    public class ChapterBL
    {

        public static dynamic saveChapter(Chapter ch)
        {
            try
            { 
                List<SqlParameter> parameters = new List<SqlParameter>(); 
                parameters.Add(new SqlParameter("@courseId", ch.courseId));
                parameters.Add(new SqlParameter("@chapterContent", ch.chapterContent)); 

                DataTable dt = DbConnection.GetDataById("spSaveChapter", parameters); 
                if (dt.Rows[0]["errorMessage"].ToString() == "Success")
                {
                    return new { status = "Success", message = "Record saved successfully"  };
                }
                else
                {
                    return new { status = "Error", message = dt.Rows[0]["errorMessage"].ToString() };
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic updateChapter(ChapterUpdate ch)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@chapterId", ch.chapterId));
                parameters.Add(new SqlParameter("@courseId", ch.courseId));
                parameters.Add(new SqlParameter("@chapterName", ch.chapterName));
                parameters.Add(new SqlParameter("@chapterDescription", ch.chapterDescription));
                parameters.Add(new SqlParameter("@chapterOrder", ch.chapterOrder)); 
                parameters.Add(new SqlParameter("@action", "Edit"));

                DataTable dt = DbConnection.GetDataById("spSaveChapter", parameters);
                int chapterId = (int)dt.Rows[0]["chapterId"];
                if (dt.Rows[0]["errorMessage"].ToString() == "Success")
                {
                    return new { status = "Success", message = "Record updated successfully", chapterId = chapterId };
                }
                else
                {
                    return new { status = "Error", message = dt.Rows[0]["errorMessage"].ToString() };
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic selectChapterById(int chapterId)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                dynamic Chapter = new System.Dynamic.ExpandoObject();
                parameters.Add(new SqlParameter("@chapterId", chapterId > 0 ? chapterId : 0));
                DataTable dt = DbConnection.GetDataById("spGetChapterById", parameters);
                if (dt.Rows.Count > 0)
                { 
                    Chapter.chapterId = (int?)dt.Rows[0]["chapterId"] ?? 0;
                    Chapter.courseId = (int?)dt.Rows[0]["courseId"] ?? 0;
                    Chapter.chapterName = dt.Rows[0]["chapterName"].ToString() ?? "";
                    Chapter.chapterDescription = dt.Rows[0]["chapterDescription"].ToString() ?? "";
                    Chapter.chapterOrder = (int?)dt.Rows[0]["chapterOrder"] ?? 0;

                    return new { status = "Success", data = Chapter };

                }
                else
                {
                    return new { status = "Success", data = Chapter, message = "No record found" };

                }

            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic deleteChapter(int ChapterId)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@ChapterId", ChapterId));

                int result = DbConnection.Delete("spDeleteChapter", parameters);
                if (result > 0)
                {
                    return new { status = "Success", message = "Record deleted successfully" };

                }
                else
                {
                    return new { status = "Error", message = "ChapterId not found" };
                }

            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic listChapter(int courseId)
        {
            List<dynamic> ChapterList = new List<dynamic>();
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@courseId", courseId > 0 ? courseId : 0));  
                DataSet ds = DbConnection.save("spGetChapter", parameters);
               
                DataTable dt = ds.Tables[0];

                if (dt.Rows.Count > 0)
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        dynamic Chapter = new System.Dynamic.ExpandoObject();
                        Chapter.chapterId = (int?)dt.Rows[i]["chapterId"] ?? 0;
                        Chapter.courseId = (int?)dt.Rows[i]["courseId"] ?? 0;
                        Chapter.chapterName = dt.Rows[i]["chapterName"].ToString() ?? "";
                        Chapter.chapterDescription = dt.Rows[i]["chapterDescription"].ToString() ?? "";
                        Chapter.chapterOrder = (int?)dt.Rows[i]["chapterOrder"] ?? 0;
                        Chapter.lessonCount = (int?)dt.Rows[i]["lessonCount"] ?? 0;


                        ChapterList.Add(Chapter);
                    }
                    return new { status = "Success", data = ChapterList};

                }
                else
                {
                    return new { status = "Success", data = ChapterList, message = "No record found" };

                }

            }

            catch (Exception e)
            {
                throw e;
            }
        }
    }
}
