﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using NationalTraining.Data;
using NationalTraining.Models;

namespace NationalTraining.BL
{
    public class UserBL
    {
        public static dynamic createUser(user user)
        {
            try
            {

                var customerId = StripeBL.addCustomer(user.firstName + " " + user.lastName, user.phone, user.email);

                List<SqlParameter> parameters = new List<SqlParameter>();
                    var encryptPassword = Common.EncryptData(user.password);
                    parameters.Add(new SqlParameter("@userId",0));
                    parameters.Add(new SqlParameter("@firstName", user.firstName));
                    parameters.Add(new SqlParameter("@lastName", user.lastName));
                    parameters.Add(new SqlParameter("@email", user.email));
                    parameters.Add(new SqlParameter("@phone", user.phone));
                    parameters.Add(new SqlParameter("@profileImage", user.profileImage));
                    parameters.Add(new SqlParameter("@password", encryptPassword));
                    parameters.Add(new SqlParameter("@customerId", customerId));
                    parameters.Add(new SqlParameter("@action", "Add")); 
                    parameters.Add(new SqlParameter("@role", user.role));
                    parameters.Add(new SqlParameter("@stateId", user.stateId == 0 ? null : user.stateId));
                    parameters.Add(new SqlParameter("@zipCode", user.zipCode));



                DataTable dt = DbConnection.GetDataById("spSaveUser", parameters);

                

                if (dt.Rows[0]["errorMessage"].ToString() == "Success")
                    {
                    dynamic userDetails = new System.Dynamic.ExpandoObject();

                    userDetails.userId = (int?)dt.Rows[0]["userId"] ?? 0;
                    userDetails.firstName = dt.Rows[0]["firstName"].ToString() ?? "";
                    userDetails.lastName = dt.Rows[0]["lastName"].ToString() ?? "";
                    userDetails.phone = dt.Rows[0]["phone"].ToString() ?? "";
                    userDetails.email = dt.Rows[0]["email"].ToString() ?? "";
                    userDetails.createdDate = dt.Rows[0]["createdDate"].ToString() ?? "";
                    userDetails.role = dt.Rows[0]["role"].ToString() ?? "";
                    userDetails.profileImage = dt.Rows[0]["profileImage"].ToString() ?? "";
                    userDetails.customerId = dt.Rows[0]["customerStripeId"].ToString() ?? "";

                    var token = LoginBL.GenerateJSONWebToken();
                    userDetails.accessToken = token;
                    return new { status = "Success", message = "Account created successfully", data = userDetails };

                    }
                    else
                    {
                        return new { status = "Error", message = dt.Rows[0]["errorMessage"].ToString() };
                    }
               

            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic updateUser(updateUser user)
        {
            try
            {

                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@userId", user.userId));
                parameters.Add(new SqlParameter("@firstName", user.firstName));
                parameters.Add(new SqlParameter("@lastName", user.lastName));
                parameters.Add(new SqlParameter("@phone", user.phone));
                parameters.Add(new SqlParameter("@profileImage", user.profileImage));
                parameters.Add(new SqlParameter("@stateId", user.stateId == 0 ? null: user.stateId));
                parameters.Add(new SqlParameter("@zipCode", user.zipCode));


                parameters.Add(new SqlParameter("@action", "Edit"));

                DataTable dt = DbConnection.GetDataById("spSaveUser", parameters);
                int userId = (int)dt.Rows[0]["userId"];
                string message = dt.Rows[0]["errorMessage"].ToString();
                if (message == "Success")
                {
                    dynamic userDetails = new System.Dynamic.ExpandoObject();

                    userDetails.userId = (int?)dt.Rows[0]["userId"] ?? 0;
                    userDetails.firstName = dt.Rows[0]["firstName"].ToString() ?? "";
                    userDetails.lastName = dt.Rows[0]["lastName"].ToString() ?? "";
                    userDetails.phone = dt.Rows[0]["phone"].ToString() ?? "";
                    userDetails.email = dt.Rows[0]["email"].ToString() ?? "";
                    userDetails.createdDate = dt.Rows[0]["createdDate"].ToString() ?? "";
                    userDetails.role = dt.Rows[0]["role"].ToString() ?? "";
                    userDetails.profileImage = dt.Rows[0]["profileImage"].ToString() ?? "";
                    userDetails.customerId = dt.Rows[0]["customerStripeId"].ToString() ?? "";
                    if (dt.Rows[0]["customerStripeId"].ToString() == "" || dt.Rows[0]["customerStripeId"].ToString() == null)
                    {
                        var customerId = StripeBL.addCustomer(dt.Rows[0]["firstName"].ToString() + " " + dt.Rows[0]["lastName"].ToString(),
                            dt.Rows[0]["phone"].ToString(), dt.Rows[0]["email"].ToString());
                        List<SqlParameter> param = new List<SqlParameter>();
                        param.Add(new SqlParameter("@userId", (int?)dt.Rows[0]["userId"]));
                        param.Add(new SqlParameter("@customerId", customerId));

                        DataSet dsCustomer = DbConnection.save("spSaveCustomer", param);
                        DataTable dtCus = dsCustomer.Tables[0];
                        userDetails.customerId = customerId;

                    }
                    var token = LoginBL.GenerateJSONWebToken();
                    userDetails.accessToken = token;
                    return new { status = "Success", message = "Account updated successfully", data = userDetails };
                }
                else
                {
                    return new { status = "Error", message = dt.Rows[0]["errorMessage"].ToString() };
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic selectUserById(int userId)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                dynamic user = new System.Dynamic.ExpandoObject();
                parameters.Add(new SqlParameter("@userId", userId > 0 ? userId : 0));
                DataTable dt = DbConnection.GetDataById("spSelectUser", parameters);
                if (dt.Rows.Count > 0)
                {
                    var decryptPassword = Common.DecryptData(dt.Rows[0]["password"].ToString());

                    user.userId = (int?)dt.Rows[0]["userId"] ?? 0; 
                    user.firstName = dt.Rows[0]["firstName"].ToString() ?? "";
                    user.lastName = dt.Rows[0]["lastName"].ToString() ?? "";
                    user.phone = dt.Rows[0]["phone"].ToString() ?? "";
                    user.email = dt.Rows[0]["email"].ToString() ?? "";
                    user.createdDate = dt.Rows[0]["createdDate"].ToString() ?? "";
                    user.role = dt.Rows[0]["role"].ToString() ?? "";
                    user.profileImage = dt.Rows[0]["profileImage"].ToString() ?? "";
                    user.stateId = (int?)dt.Rows[0]["stateId"] ?? 0;
                    user.stateName = dt.Rows[0]["stateName"] ?? 0;
                    user.zipCode = dt.Rows[0]["zipcode"].ToString() ?? "";

                    return new { status = "Success", data = user };
                }

                else
                {
                    return new { status = "Success", data = user , message= "No record found" };

                }

            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic deleteUser(int userId)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@userId", userId)); 

                int result = DbConnection.Delete("spDeleteUser", parameters);
                if (result> 0)
                {
                    return new { status = "Success", message= "Record deleted successfully" };

                }
                else
                {
                    return new { status = "Error", message="UserId not found" };
                }

            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic listUser(int count, int offset, string firstName, string lastName, string email,
                    string phone, string role, int stateId, string zipCode)
        {
            List<dynamic> userList = new List<dynamic>();
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@Count", count > 0 ? count : 10));
                parameters.Add(new SqlParameter("@Offset", offset > 0 ? offset : 0));
                parameters.Add(new SqlParameter("@firstName", firstName));
                parameters.Add(new SqlParameter("@lastName", lastName));
                parameters.Add(new SqlParameter("@email", email));
                parameters.Add(new SqlParameter("@phone", phone));
                parameters.Add(new SqlParameter("@role", role));
                parameters.Add(new SqlParameter("@stateId", stateId));
                parameters.Add(new SqlParameter("@zipCode", zipCode));

                DataSet ds = DbConnection.save("spGetUser", parameters);
                DataTable dt = ds.Tables[1];
                DataTable dt1 = ds.Tables[0];

                if (dt.Rows.Count > 0)
                {
                   
                    return new { status = "Success", data = dt, count = (int?)dt1.Rows[0][0] ?? 0 };

                }
                else
                {
                    return new { status = "Success", data = dt, message = "No record found" };

                }


            }

            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic GenerateOTP([FromBody]generateOTP generateOTP)
        {
            try
            {
                string result = "";
                string OTPValue = Common.GenerateOTP();

                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@OTPValue", OTPValue));
                parameters.Add(new SqlParameter("@email", generateOTP.email));
                parameters.Add(new SqlParameter("@otpType", generateOTP.otpType));
               

                DataTable dt = DbConnection.GetDataById("spGenerateOTP", parameters);
                if (dt.Rows[0][0].ToString() == "Success")
                {
                    string fromMail = Common.GetConnectionString("FromEmail", "fromMail");
                   string results = Common.SendOTP(fromMail, generateOTP.email, "Verify OTP", "Hi User, your OTP is " + OTPValue + " and it's expiry time is 15 minutes.");
                 
                    if (results == "Mail sent successfully.")
                    {
                        return new { status = "Success", message = "Mail sent successfully." };
                    }
                    else
                    {
                        return new { status = "Error", message = "Bad Request" };
                    }
                }
                else
                {
                    return new { status = "Error", message = dt.Rows[0][0].ToString() };
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic forgetPassword(forgetPassword forgetPassword)
        {
            try
            {
                var encryptedpassword = Common.EncryptData(forgetPassword.password);
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@email", forgetPassword.email));
                parameters.Add(new SqlParameter("@password", encryptedpassword));

                DataTable dt = DbConnection.GetDataById("spForgetPassword", parameters);
                if (dt.Rows[0][0].ToString() == "Success")
                {
                    return new { status = "Success", message = "Password Updated Successfully." };

                }
                else
                {
                    return new { status = "Error", message = dt.Rows[0][0].ToString() };
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }
        public static dynamic changePassword(changePassword changePassword)
        {
            try
            {
                var newPassword = Common.EncryptData(changePassword.newPassword);
                var oldPassword = Common.EncryptData(changePassword.oldPassword);

                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@userId", changePassword.userId));
                parameters.Add(new SqlParameter("@newPassword", newPassword));
                parameters.Add(new SqlParameter("@oldPassword", oldPassword));

                DataTable dt = DbConnection.GetDataById("spChangePassword", parameters);
                if (dt.Rows[0][0].ToString() == "Success")
                {
                    return new { status = "Success", message = "Password Updated Successfully." };

                }
                else
                {
                    return new { status = "Error", message = dt.Rows[0][0].ToString() };
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }
        public static dynamic verifyOTP([FromBody]OTPverify OTPverify)
        {
            try
            {
                
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@oTPValue", OTPverify.oTPValue));
                parameters.Add(new SqlParameter("@email", OTPverify.email));
                parameters.Add(new SqlParameter("@otpType", OTPverify.oTPType));

                DataTable dt = DbConnection.GetDataById("spVerifyOTP", parameters);

                if (dt.Rows[0][0].ToString() == "Success")
                {
                    return new { status = "Success", message = "OTP Verified Successfully" };

                }
                else
                {
                    return new { status = "Error", message = dt.Rows[0][0].ToString() };
                }

            }
            catch (Exception e)
            {
                throw e;
            }
        }

        //public static dynamic getEndUserList()
        //{
        //    try
        //    {
        //        List<SqlParameter> parameters = new List<SqlParameter>();
        //        dynamic user = new System.Dynamic.ExpandoObject();

        //        DataSet ds = DbConnection.GetDataSet("spGetEndUser");

        //        return new { status = "Success", data = ds.Tables[0] };
        //    }
        //    catch (Exception e)
        //    {
        //        throw e;
        //    }
        //}

        public static dynamic getEndUserDetails(int userId)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                dynamic user = new System.Dynamic.ExpandoObject();
                parameters.Add(new SqlParameter("@userId", userId > 0 ? userId : 0));

                DataTable dt = DbConnection.GetDataById("spGetEndUserDetails", parameters);

                if (dt.Rows.Count > 0)
                {

                    user.userId = (int?)dt.Rows[0]["userId"] ?? 0;
                    user.firstName = dt.Rows[0]["firstName"].ToString() ?? "";
                    user.lastName = dt.Rows[0]["lastName"].ToString() ?? "";
                    user.stateId = (int?)dt.Rows[0]["stateId"] ?? 0;
                    user.stateName = dt.Rows[0]["stateName"] ?? 0;
                    user.zipcode = dt.Rows[0]["zipcode"].ToString() ?? "";
                    user.phone = dt.Rows[0]["phone"].ToString() ?? "";
                    user.email = dt.Rows[0]["email"].ToString() ?? "";
                    user.createdDate = dt.Rows[0]["createdDate"].ToString() ?? "";
                    user.profileImage = dt.Rows[0]["profileImage"].ToString() ?? "";
                    user.completedCourseDetails = dt.Rows[0]["completedCourseDetails"].ToString() ?? "";
                    user.pendingCourseDetails = dt.Rows[0]["pendingCourseDetails"].ToString() ?? "";
                    return new { status = "Success", data = user };
                }
                else
                {
                    return new { status = "Success", data = user, message = "No record found" };

                }

            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic getPaymentHistory(int count, int offset, string courseName, string email,string firstName,string lastName,string phone,
            int userId,int courseId,string fromDate, string toDate)
        {
          
            List<dynamic> courseList = new List<dynamic>();
            try
            {

                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@count", count > 0 ? count : 10));
                parameters.Add(new SqlParameter("@Offset", offset > 0 ? offset : 0));
                parameters.Add(new SqlParameter("@courseName", courseName));
                parameters.Add(new SqlParameter("@email", email));
                parameters.Add(new SqlParameter("@firstName", firstName));
                parameters.Add(new SqlParameter("@lastName", lastName));
                parameters.Add(new SqlParameter("@phone", phone));
                parameters.Add(new SqlParameter("@userId", userId));
                parameters.Add(new SqlParameter("@courseId", courseId));
                parameters.Add(new SqlParameter("@fromDate", fromDate));
                parameters.Add(new SqlParameter("@toDate", toDate));

                DataSet ds = DbConnection.save("spGetPaymentHistory", parameters);
                DataTable dt = ds.Tables[1];
                DataTable dt1 = ds.Tables[0];

                if (dt.Rows.Count > 0)
                {
                     
                    return new { status = "Success", data = dt, count = (int?)dt1.Rows[0][0] ?? 0 };

                }
                else
                {
                    return new { status = "Success", data = dt, message = "No record found" };

                }

            }

            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic getState()
        { 
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                
                DataSet ds = DbConnection.save("spGetState", parameters);
                DataTable dt = ds.Tables[0];
                 

                if (dt.Rows.Count > 0)
                {

                    return new { status = "Success", data = dt};

                }
                else
                {
                    return new { status = "Success", data = dt, message = "No record found" };

                }


            }

            catch (Exception e)
            {
                throw e;
            }
        }


    }
}
