﻿using NationalTraining.Data;
using NationalTraining.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace NationalTraining.BL
{
    public class QuestionBL
    {

        public static dynamic saveQuestion(Question qu)
        {
            try
            {

                //string questionContent = JsonConvert.SerializeObject(qu.questionContent);


                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@referenceId", qu.referenceId)); 
                parameters.Add(new SqlParameter("@questionContent", qu.questionContent));
                parameters.Add(new SqlParameter("@createdBy", qu.createdBy));
                parameters.Add(new SqlParameter("@referenceType", qu.referenceType));


                DataTable dt = DbConnection.GetDataById("spSaveQuestion", parameters); 
                if (dt.Rows[0]["errorMessage"].ToString() == "Success")
                {
                    return new { status = "Success", message = "Record saved successfully"};
                }
                else
                {
                    return new { status = "Error", message = dt.Rows[0]["errorMessage"].ToString() };
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }


        public static dynamic selectQuestion(int questionId)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                dynamic  question = new System.Dynamic.ExpandoObject();
                parameters.Add(new SqlParameter("@questionId", questionId > 0 ? questionId : 0));
                DataTable dt = DbConnection.GetDataById("spGetQuestionById", parameters);
                if (dt.Rows.Count > 0)
                {
                    question.questionId = (int?)dt.Rows[0]["questionId"] ?? 0;
                    question.referenceId = (int?)dt.Rows[0]["referenceId"] ?? 0;
                    question.referenceType = dt.Rows[0]["referenceType"].ToString() ?? "";
                    question.questionLable = dt.Rows[0]["questionLable"].ToString() ?? "";
                    question.questionType = dt.Rows[0]["questionType"].ToString() ?? "";
                    question.questionOptions = dt.Rows[0]["questionOptions"].ToString() ?? ""; 
                    question.answer = dt.Rows[0]["answer"].ToString() ?? "";
                    question.questionDescription = dt.Rows[0]["questionDescription"].ToString() ?? "";
                    question.sortOrder = (int?)dt.Rows[0]["sortOrder"] ?? 0;
 
                    return new { status = "Success", data = question };

                }
                else
                {
                    return new { status = "Success", data = question, message = "No record found" };

                }

            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic deleteQuestion(int questionId)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@questionId", questionId));

                int result = DbConnection.Delete("spDeleteQuestion", parameters);
                if (result > 0)
                {
                    return new { status = "Success", message = "Record deleted successfully" };

                }
                else
                {
                    return new { status = "Error", message = "questionId not found" };
                }

            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic listCourseQuestion(int count, int offset, string courseName, int courseId)
        {
            List<dynamic> vehicleTypeList = new List<dynamic>();
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@Count", count > 0 ? count : 10));
                parameters.Add(new SqlParameter("@Offset", offset > 0 ? offset : 0)); 
                parameters.Add(new SqlParameter("@courseName", courseName));
                parameters.Add(new SqlParameter("@courseId", courseId));

                DataSet ds = DbConnection.save("spGetCourseQuestion", parameters);
                DataTable dt = ds.Tables[1];
                DataTable dt1 = ds.Tables[0];

                if (dt.Rows.Count > 0)
                {
                    
                    return new { status = "Success", data = dt, count = (int?)dt1.Rows[0][0] ?? 0 };

                }
                else
                {
                    return new { status = "Success", data = vehicleTypeList, message = "No record found" };

                }

            }

            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic listChapterQuestion(int count, int offset, string chapterName, int chapterId)
        {
            List<dynamic> vehicleTypeList = new List<dynamic>();
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@Count", count > 0 ? count : 10));
                parameters.Add(new SqlParameter("@Offset", offset > 0 ? offset : 0));
                parameters.Add(new SqlParameter("@chapterName", chapterName));
                parameters.Add(new SqlParameter("@chapterId", chapterId));

                DataSet ds = DbConnection.save("spGetChapterQuestion", parameters);
                DataTable dt = ds.Tables[1];
                DataTable dt1 = ds.Tables[0];

                if (dt.Rows.Count > 0)
                {

                    return new { status = "Success", data = dt, count = (int?)dt1.Rows[0][0] ?? 0 };

                }
                else
                {
                    return new { status = "Success", data = vehicleTypeList, message = "No record found" };

                }

            }

            catch (Exception e)
            {
                throw e;
            }
        }
        public static dynamic getQuestion(int referenceId, string referenceType)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@referenceId", referenceId));
                parameters.Add(new SqlParameter("@referenceType", referenceType));

                dynamic questionDetails = new System.Dynamic.ExpandoObject();

                DataSet ds = DbConnection.save("spGetQuestion", parameters);
                if (ds.Tables[0].Rows.Count > 0 || ds.Tables[1].Rows.Count > 0)
                {
                    if (ds.Tables[1].Rows.Count > 0)
                    {
                        questionDetails.passScore = (decimal?)ds.Tables[1].Rows[0]["passScore"] ?? 0;
                        questionDetails.courseId = (int?)ds.Tables[1].Rows[0]["referenceId"] ?? 0;
                    }
                    return new { status = "Success", questions = ds.Tables[0],questionDetails= questionDetails };

                }
                else
                {
                    return new { status = "Success", questions = ds.Tables[0], questionDetails= questionDetails, message = "No record found" };

                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic GetQuestionAutoComplete(int count, int offset, string search)
        {
            try
            {
                List<dynamic> questionList = new List<dynamic>();


                List<SqlParameter> parameters = new List<SqlParameter>();
                dynamic user = new System.Dynamic.ExpandoObject();
                parameters.Add(new SqlParameter("@Count", count > 0 ? count : 10));
                parameters.Add(new SqlParameter("@Offset", offset > 0 ? offset : 0));
                parameters.Add(new SqlParameter("@search", search == null ? "" : search));

                DataSet ds = DbConnection.save("spGetQuestionAutoComplete", parameters);
                DataTable dt = ds.Tables[1];
                DataTable dt1 = ds.Tables[0];
                if (dt.Rows.Count > 0)
                {

                    return new { status = "Success", data = dt, count = (int?)dt1.Rows[0][0] ?? 0 };

                }
                else
                {
                    return new { status = "Success", data = questionList, message = "No record found" };

                }

            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic GetTestCondition(int courseId)
        {
            try
            {
                dynamic data = new System.Dynamic.ExpandoObject();

                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@courseId", courseId));

                dynamic questionDetails = new System.Dynamic.ExpandoObject();

                DataSet ds = DbConnection.save("spGetTestConditon", parameters);
                DataTable dt = ds.Tables[0];
                DataTable dt1 = ds.Tables[1];


                data.isCourseWithoutTest = (bool?)dt.Rows[0]["isCourseWithoutTest"] ?? false;
                data.isChapterWithoutTest = (bool?)dt1.Rows[0]["isChapterWithoutTest"] ?? false;

                return new { status = "Success", data = data };

            }
            catch (Exception e)
            {
                throw e;
            }
        }

    }
}
