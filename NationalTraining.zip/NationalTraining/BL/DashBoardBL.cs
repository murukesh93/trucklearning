﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.AspNetCore.Mvc;
using NationalTraining.Data;
using NationalTraining.Models;

namespace NationalTraining.BL
{
    public class DashBoardBL
    {
        public static dynamic adminDashBoard()
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                dynamic user = new System.Dynamic.ExpandoObject();

                DataSet ds = DbConnection.GetDataSet("spAdminDashBoard");

                return new {
                    status = "Success", 
                    adminCount = ds.Tables[0].Rows[0]["adminCount"], userCount= ds.Tables[1].Rows[0]["userCount"],
                    courseCount = ds.Tables[2].Rows[0]["courseCount"], vehicleCount = ds.Tables[3].Rows[0]["vehicleCount"],
                    MonthlyUserReport= ds.Tables[4],
                    recentCourse = ds.Tables[5],
                    recentUser= ds.Tables[6],
                    courseVSUserCount = ds.Tables[7],
                    totalProfit = ds.Tables[8].Rows[0]["totalProfit"],
                    recentPayment = ds.Tables[9],
                    monthvsProfit = ds.Tables[10],
                    todayPayment = ds.Tables[11].Rows[0]["todayPayment"],
                    //, truckCourseCount= ds.Tables[5]
                };

            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic getUserDashboard(int userId)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                dynamic user = new System.Dynamic.ExpandoObject();
                parameters.Add(new SqlParameter("@userId", userId > 0 ? userId : 0));
                DataSet ds = DbConnection.save("spGetFeatured", parameters);

                return new
                {
                    status = "Success",
                    FeatureCourse = ds.Tables[0],
                    lastSeenCourse = ds.Tables[1],
                   
                };
            }
            catch (Exception e)
            {
                throw e;
            }
        }

    }
}
