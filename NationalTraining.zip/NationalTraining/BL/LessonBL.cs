﻿using NationalTraining.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static NationalTraining.Models.Lesson;
using Newtonsoft.Json;

namespace NationalTraining.BL
{
    public class LessonBL
    {

        public static dynamic createLesson(CreateLesson cl)
        {
            try
            {

                string lessons = JsonConvert.SerializeObject(cl.lessonDetails);


                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@chapterId", cl.chapterId));
                parameters.Add(new SqlParameter("@lessonDetails", lessons));

                //parameters.Add(new SqlParameter("@lessonName", cl.lessonName));
                //parameters.Add(new SqlParameter("@lessonDescription", cl.lessonDescription));
                //parameters.Add(new SqlParameter("@lessonOrder", cl.lessonOrder));
                //parameters.Add(new SqlParameter("@action","add"));

                DataTable dt = DbConnection.GetDataById("spSaveLesson", parameters);
                if (dt.Rows[0]["errorMessage"].ToString() == "Success")
                {
                    return new { status = "Success", message = "Record saved successfully" };
                }
                else
                {
                    return new { status = "Error", message = dt.Rows[0]["errorMessage"].ToString() };
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        //public static dynamic updateLesson(UpdateLesson ul)
        //{
        //    try
        //    {

        //        List<SqlParameter> parameters = new List<SqlParameter>();
        //        parameters.Add(new SqlParameter("@lessonId", ul.lessonId));
        //        parameters.Add(new SqlParameter("@lessonName", ul.lessonName));
        //        parameters.Add(new SqlParameter("@lessonDescription", ul.lessonDescription));
        //        parameters.Add(new SqlParameter("@lessonOrder", ul.lessonOrder));


        //        DataTable dt = DbConnection.GetDataById("spSaveLesson", parameters);
        //        if (dt.Rows[0]["errorMessage"].ToString() == "Success")
        //        {
        //            return new { status = "Success", message = "Record updated successfully" };
        //        }
        //        else
        //        {
        //            return new { status = "Error", message = dt.Rows[0]["errorMessage"].ToString() };
        //        }
        //    }
        //    catch (Exception e)
        //    {
        //        throw e;
        //    }
        //}
        public static dynamic selectLesson(int lessonId)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                dynamic lesson = new System.Dynamic.ExpandoObject();
                parameters.Add(new SqlParameter("@lessonId", lessonId > 0 ? lessonId : 0));
                DataTable dt = DbConnection.GetDataById("spSelectLesson", parameters);
                if (dt.Rows.Count > 0)
                {
                    lesson.lessonId = (int?)dt.Rows[0]["lessonId"] ?? 0;
                    lesson.chapterId = (int?)dt.Rows[0]["chapterId"] ?? 0;
                    lesson.lessonName = dt.Rows[0]["lessonName"].ToString() ?? "";
                    lesson.lessonDescription = dt.Rows[0]["lessonDescription"].ToString() ?? "";
                    lesson.lessonOrder = dt.Rows[0]["lessonOrder"].ToString() ?? "";

                    return new { status = "Success", data = lesson };

                }
                else
                {
                    return new { status = "Success", data = lesson, message = "No record found" };

                }

            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic getLesson(int lessonId)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                dynamic lesson = new System.Dynamic.ExpandoObject();
                parameters.Add(new SqlParameter("@lessonId", lessonId > 0 ? lessonId : 0));
                DataTable dt = DbConnection.GetDataById("spSelectLesson", parameters);
                if (dt.Rows.Count > 0)
                {
                    lesson.lessonId = (int?)dt.Rows[0]["lessonId"] ?? 0;
                    lesson.chapterId = (int?)dt.Rows[0]["chapterId"] ?? 0;
                    lesson.lessonName = dt.Rows[0]["lessonName"].ToString() ?? "";
                    lesson.lessonDescription = dt.Rows[0]["lessonDescription"].ToString() ?? "";
                    lesson.lessonOrder = dt.Rows[0]["lessonOrder"].ToString() ?? "";

                    return new { status = "Success", data = lesson };

                }
                else
                {
                    return new { status = "Success", data = lesson, message = "No record found" };

                }

            }
            catch (Exception e)
            {
                throw e;
            }
        }
        public static dynamic deleteLesson(int lessonId)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@lessonId", lessonId));

                int result = DbConnection.Delete("spDeleteLesson", parameters);
                if (result > 0)
                {
                    return new { status = "Success", message = "Record deleted successfully" };

                }
                else
                {
                    return new { status = "Error", message = "questionId not found" };
                }

            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic listLesson(int count, int offset, string lessonName, int chapterId)
        {
            List<dynamic> lessonList = new List<dynamic>();
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@Count", count > 0 ? count : 10));
                parameters.Add(new SqlParameter("@Offset", offset > 0 ? offset : 0));
                parameters.Add(new SqlParameter("@lessonName", lessonName));
                parameters.Add(new SqlParameter("@chapterId", chapterId));

                DataSet ds = DbConnection.save("spGetLesson", parameters);
                DataTable dt = ds.Tables[1];
                DataTable dt1 = ds.Tables[0];

                if (dt.Rows.Count > 0)
                {

                    return new { status = "Success", data = dt, count = (int?)dt1.Rows[0][0] ?? 0 };

                }
                else
                {
                    return new { status = "Success", data = lessonList, message = "No record found" };

                }

            }

            catch (Exception e)
            {
                throw e;
            }
        }
        public static dynamic createCourseContent(CourseContent con)
        {
            try
            {
                string mediaContent = JsonConvert.SerializeObject(con.mediaContentDetails);

                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@lessonId", con.lessonId));
                parameters.Add(new SqlParameter("@mediaContent", mediaContent));

                DataTable dt = DbConnection.GetDataById("spSaveMediaContent", parameters);
                if (dt.Rows[0]["errorMessage"].ToString() == "Success")
                {
                    return new { status = "Success", message = "Record saved successfully" };

                }
                else
                {
                    return new { status = "Error", message = dt.Rows[0]["errorMessage"].ToString() };
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic updateCourseContent(UpdateCourseContent con)
        {
            try
            {

                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@mediaContentId", con.mediaContentId));
                parameters.Add(new SqlParameter("@contentTitle", con.contentTitle));
                parameters.Add(new SqlParameter("@contentDescription", con.contentDescription));
                parameters.Add(new SqlParameter("@contentOrder", con.contentOrder));
                parameters.Add(new SqlParameter("@contentType", con.contentType));
                parameters.Add(new SqlParameter("@contentURL", con.contentURL));
                parameters.Add(new SqlParameter("@duration", con.duration));

                DataTable dt = DbConnection.GetDataById("spUpdateCourseContent", parameters);
                if (dt.Rows[0]["errorMessage"].ToString() == "Success")
                {
                    return new { status = "Success", message = "Record updated successfully" };
                }
                else
                {
                    return new { status = "Error", message = dt.Rows[0]["errorMessage"].ToString() };
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic selectChapterLessons(int chapterId)
        {
            try
            {

                List<dynamic> contentList = new List<dynamic>();
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@chapterId", chapterId > 0 ? chapterId : 0));
                dynamic courseobj = new System.Dynamic.ExpandoObject();
                DataSet ds = DbConnection.save("spGetLessonByChapterId", parameters);

                if (ds.Tables[0].Rows.Count > 0)
                {

                    return new { status = "Success", data = ds.Tables[0] };
                }

                else
                {
                    return new { status = "Error", data = ds.Tables[0], message = "No record found" };
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }
        public static dynamic GetMediaContent(int lessonId)
        {
            try
            {

                List<dynamic> contentList = new List<dynamic>();
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@lessonId", lessonId > 0 ? lessonId : 0));
                dynamic courseobj = new System.Dynamic.ExpandoObject();
                DataSet ds = DbConnection.save("spGetMediaContent", parameters);

                if (ds.Tables[0].Rows.Count > 0)
                {

                    return new { status = "Success", data = ds.Tables[0] };
                }

                else
                {
                    return new { status = "Error", data = ds.Tables[0], message = "No record found" };
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic deleteCourseContent(int mediaContentId)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@mediaContentId", mediaContentId));

                int result = DbConnection.Delete("spDeleteCourseContent", parameters);
                if (result > 0)
                {
                    return new { status = "Success", message = "Record deleted successfully" };

                }
                else
                {
                    return new { status = "Error", message = "mediaContentId not found" };
                }

            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic selectMediaContent(int mediaContentId)
        {
            try
            {
                dynamic mediaContent = new System.Dynamic.ExpandoObject();

                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@mediaContentId", mediaContentId));

                DataTable dt = DbConnection.GetDataById("spGetMediaContentById", parameters);
                if (dt.Rows.Count > 0)
                {

                    mediaContent.mediaContentId = (int?)dt.Rows[0]["mediaContentId"] ?? 0;
                    mediaContent.lessonId = (int?)dt.Rows[0]["lessonId"] ?? 0;
                    mediaContent.contentTitle = dt.Rows[0]["contentTitle"].ToString() ?? "";
                    mediaContent.contentDescription = dt.Rows[0]["contentDescription"].ToString() ?? "";
                    mediaContent.contentURL = dt.Rows[0]["contentURL"].ToString() ?? "";
                    mediaContent.contentType = dt.Rows[0]["contentType"].ToString() ?? "";
                    mediaContent.contentOrder = dt.Rows[0]["contentOrder"].ToString() ?? ""; ;
                    mediaContent.duration = dt.Rows[0]["duration"].ToString() ?? "";
                    return new { status = "Success", data = mediaContent };

                }
                else
                {
                    return new { status = "Error", data = mediaContent, message = "No record found" };
                }

            }
            catch (Exception e)
            {
                throw e;
            }
        }


    }
}
