﻿using NationalTraining.Data;
using NationalTraining.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace NationalTraining.BL
{
    public class VehicleTypeBL
    {

        public static dynamic createVehicleType(VehicleTypes veh)
        {
            try
            {  
                    List<SqlParameter> parameters = new List<SqlParameter>();
                    parameters.Add(new SqlParameter("@vehicleTypeId", 0));
                    parameters.Add(new SqlParameter("@vehicleType", veh.vehicleType));
                    parameters.Add(new SqlParameter("@vehicleName", veh.vehicleName));
                    parameters.Add(new SqlParameter("@description", veh.description));
                    parameters.Add(new SqlParameter("@vehicleImage", veh.vehicleImage));
                    parameters.Add(new SqlParameter("@action", "Add")); 

                    DataTable dt = DbConnection.GetDataById("spSaveVehicleType", parameters);
                string message = dt.Rows[0]["errorMessage"].ToString();

                if (message == "Success")
                     {
                    int vehicleTypeId = (int)dt.Rows[0]["vehicleTypeId"];

                    return new { status = "Success", message = "Record saved successfully", vehicleTypeId = vehicleTypeId };
                     }
                     else if (message.Contains("UNIQUE KEY constraint") == true)
                     {
                         return new { status = "Error", message = "Vehicle name already exists" };
                     }
                    else
                    {
                        return new { status = "Error", message = dt.Rows[0]["errorMessage"].ToString()};
                    }
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic updateVehicleType(UpdateVehicleType veh)
        {
            try
            {

                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@vehicleTypeId", veh.vehicleTypeId));
                parameters.Add(new SqlParameter("@vehicleType", veh.vehicleType));
                parameters.Add(new SqlParameter("@description", veh.description));
                parameters.Add(new SqlParameter("@vehicleImage", veh.vehicleImage));
                parameters.Add(new SqlParameter("@vehicleName", veh.vehicleName));
                parameters.Add(new SqlParameter("@action", "Edit"));

                DataTable dt = DbConnection.GetDataById("spSaveVehicleType", parameters);
                int vehicleTypeId = (int)dt.Rows[0]["vehicleTypeId"];
                string message = dt.Rows[0]["errorMessage"].ToString();

                if (message == "Success")
                {
                    return new { status = "Success", message = "Record updated successfully", vehicleTypeId = vehicleTypeId };
                }
                else if (message.Contains("UNIQUE KEY constraint") == true)
                {
                    return new { status = "Error", message = "Vehicle name already exists" };
                }
                else
                {
                    return new { status = "Error", message = dt.Rows[0]["errorMessage"].ToString() };
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic selectvehicleTypeById(int vehicleTypeId)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                dynamic vehicleType = new System.Dynamic.ExpandoObject();
                parameters.Add(new SqlParameter("@vehicleTypeId", vehicleTypeId > 0 ? vehicleTypeId : 0));
                DataTable dt = DbConnection.GetDataById("spSelectVehicleType", parameters);
                if (dt.Rows.Count > 0)
                {  
                    vehicleType.vehicleTypeId = (int?)dt.Rows[0]["vehicleTypeId"] ?? 0;
                    vehicleType.vehicleType = dt.Rows[0]["vehicleType"].ToString() ?? "";
                    vehicleType.description = dt.Rows[0]["description"].ToString() ?? "";
                    vehicleType.vehicleImage = dt.Rows[0]["vehicleImage"].ToString() ?? "";
                    vehicleType.vehicleName = dt.Rows[0]["vehicleName"].ToString() ?? "";

                    return new { status = "Success", data = vehicleType};

                }
                else
                {
                    return new { status = "Success", data = vehicleType, message = "No record found" };

                }

            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic deletevehicleType(int vehicleTypeId)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@vehicleTypeId", vehicleTypeId));

                int result = DbConnection.Delete("spDeleteVehicleType", parameters);
                if (result > 0)
                {
                    return new { status = "Success", message = "Record deleted successfully" };

                }
                else
                {
                    return new { status = "Error", message = "vehicleTypeId not found" };
                }

            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic listvehicleType(int count, int offset, string vehicleType, string description, string vehicleName)
        {
            List<dynamic> vehicleTypeList = new List<dynamic>();
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@Count", count > 0 ? count : 10));
                parameters.Add(new SqlParameter("@Offset", offset > 0 ? offset : 0));
                parameters.Add(new SqlParameter("@vehicleType", vehicleType));
                parameters.Add(new SqlParameter("@vehicleName", vehicleName));

                parameters.Add(new SqlParameter("@description", description)); 

                DataSet ds = DbConnection.save("spGetvehicleType", parameters);
                DataTable dt = ds.Tables[1];
                DataTable dt1 = ds.Tables[0];

                if (dt.Rows.Count > 0)
                {
                    //for (int i = 0; i < dt.Rows.Count; i++)
                    //{
                    //    dynamic vehicle = new System.Dynamic.ExpandoObject();
                    //    vehicle.vehicleTypeId = (int?)dt.Rows[i]["vehicleTypeId"] ?? 0;
                    //    vehicle.vehicleType = dt.Rows[i]["vehicleType"] ?? 0; 
                    //    vehicle.description = dt.Rows[i]["description"].ToString() ?? "";
                    //    vehicle.vehicleImage = dt.Rows[i]["vehicleImage"].ToString() ?? "";
                    //    vehicle.vehicleName = dt.Rows[i]["vehicleName"] ?? 0;

                    //    vehicleTypeList.Add(vehicle);
                    //}
                    return new { status = "Success", data = ds.Tables[1], count = (int?)dt1.Rows[0][0] ?? 0 };

                }
                else
                {
                    return new { status = "Success", data = ds.Tables[1], message = "No record found" };

                }

            }

            catch (Exception e)
            {
                throw e;
            }
        }
    }
}
