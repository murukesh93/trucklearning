﻿using NationalTraining.Data;
using NationalTraining.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace NationalTraining.BL
{
    public class WishlistBL
    {


        public static dynamic createWishlist(Wishlist ws)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@userId", ws.userId));
                parameters.Add(new SqlParameter("@lessonId", ws.lessonId));
               

                DataTable dt = DbConnection.GetDataById("spSavewishlist", parameters);
                int wishlistId = (int)dt.Rows[0]["wishlistId"];
                if (dt.Rows[0]["errorMessage"].ToString() == "Success")
                {
                    return new { status = "Success", message = "Record saved successfully", wishlistId = wishlistId };
                }
                else
                {
                    return new { status = "Error", message = dt.Rows[0]["errorMessage"].ToString() };
                }
               
            }
            catch (Exception e)
            {
                throw e;
            }
        }
         

        public static dynamic deleteWishlist(int wishlistId)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@wishlistId", wishlistId));

                int result = DbConnection.Delete("spDeleteWishlist", parameters);
                if (result > 0)
                {
                    return new { status = "Success", message = "Record deleted successfully" };

                }
                else
                {
                    return new { status = "Error", message = "wishlistId not found" };
                }


            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic listwishList(int count, int offset, string contentTitle, int userId)
        {
            List<dynamic> wishList = new List<dynamic>();
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@Count", count > 0 ? count : 10));
                parameters.Add(new SqlParameter("@Offset", offset > 0 ? offset : 0));
                parameters.Add(new SqlParameter("@contentTitle", contentTitle));
                parameters.Add(new SqlParameter("@userId", userId));

                DataSet ds = DbConnection.save("spGetWishlist", parameters);
                DataTable dt = ds.Tables[1];
                DataTable dt1 = ds.Tables[0];

                if (dt.Rows.Count > 0)
                {
                    //for (int i = 0; i < dt.Rows.Count; i++)
                    //{
                    //    dynamic obj= new System.Dynamic.ExpandoObject();
                    //    obj.wishlistId = (int?)dt.Rows[i]["wishlistId"] ?? 0;
                    //    obj.userId = (int?)dt.Rows[i]["userId"] ?? 0;
                    //    obj.lessonId = dt.Rows[i]["lessonId"].ToString() ?? "";
                    //    obj.courseId = (int?)dt.Rows[i]["courseId"] ?? 0;
                    //    obj.courseName = dt.Rows[i]["courseName"].ToString() ?? "";
                    //    obj.chapterName = dt.Rows[i]["chapterName"].ToString() ?? "";
                    //    obj.courseURL = dt.Rows[i]["courseURL"].ToString() ?? "";
                    //    obj.contentTitle = dt.Rows[i]["contentTitle"].ToString() ?? "";
                    //    obj.contentDescription = dt.Rows[i]["contentDescription"].ToString() ?? "";
                    //    obj.contentURL = dt.Rows[i]["contentURL"].ToString() ?? "";
                    //    obj.contentType = dt.Rows[i]["contentType"].ToString() ?? "";
                    //    obj.duration = dt.Rows[i]["duration"].ToString() ?? "";

                    //    wishList.Add(obj);
                    //}
                    //return new { status = "Success", data = wishList, count = (int?)dt1.Rows[0][0] ?? 0 };
                    return new { status = "Success", data = dt, count = (int?)dt1.Rows[0][0] ?? 0 };

                }
                else
                {
                    return new { status = "Success", data = wishList, message = "No record found" };

                }

            }

            catch (Exception e)
            {
                throw e;
            }
        }

    }
}
