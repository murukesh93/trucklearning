﻿using NationalTraining.Data;
using NationalTraining.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace NationalTraining.BL
{
    public class TakeCourseBL
    {
        public static dynamic startCourse(StartCourse st)
        {
            try
            {

                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@courseId", st.courseId));
                parameters.Add(new SqlParameter("@userId", st.userId)); 

                DataTable dt = DbConnection.GetDataById("spStartCourse", parameters);
                int courseDetailId = (int)dt.Rows[0]["courseDetailId"];
                string message = dt.Rows[0]["errorMessage"].ToString();
                if (message == "Success")
                {
                    decimal passScore = (decimal)dt.Rows[0]["passScore"];

                    return new { status = "Success", message = "Record saved successfully", courseDetailId = courseDetailId, passScore= passScore };

                }
                else
                {
                    return new { status = "Error", message = dt.Rows[0]["errorMessage"].ToString()};
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        } 
        public static dynamic endCourse(EndCourse ed)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@courseDetailId", ed.courseDetailId));
                parameters.Add(new SqlParameter("@courseId", ed.courseId));
                parameters.Add(new SqlParameter("@userId", ed.userId));
               

                DataTable dt = DbConnection.GetDataById("spEndCourse", parameters);
               
                string message = dt.Rows[0]["errorMessage"].ToString();
                if (message == "Success")
                {
                    return new { status = "Success", message = "Record saved successfully" };

                }
                else
                {
                    return new { status = "Error", message = dt.Rows[0]["errorMessage"].ToString() };
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic saveCourseLog(SaveCourseLog sl)
        {
            try
            {

                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@contentStatus", sl.contentStatus));
                parameters.Add(new SqlParameter("@courseDetailId", sl.courseDetailId));
                parameters.Add(new SqlParameter("@mediaContentId", sl.mediaContentId));
                parameters.Add(new SqlParameter("@progressDetails", sl.progressDetails)); 

                DataTable dt = DbConnection.GetDataById("spSaveCourseLog", parameters);
                int courseLogDetailId = (int)dt.Rows[0]["courseLogDetailId"];
                string message = dt.Rows[0]["errorMessage"].ToString();
                if (message == "Success")
                {
                    return new { status = "Success", message = "Record saved successfully", courseLogDetailId = courseLogDetailId };

                }
                else
                {
                    return new { status = "Error", message = dt.Rows[0]["errorMessage"].ToString() };
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }


        public static dynamic courses(int userId, string search)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                dynamic user = new System.Dynamic.ExpandoObject();
                parameters.Add(new SqlParameter("@userId", userId > 0 ? userId : 0));
                parameters.Add(new SqlParameter("@search", search == null ? "" : search));

                DataSet ds = DbConnection.save("spGetUserCourseDetails", parameters);
                if (ds.Tables[0].Rows.Count > 0)
                {

                    return new { status = "Success", data = ds.Tables[0] };
                }
                else
                {
                    return new { status = "Success", data = ds.Tables[0], message = "No record found" };
                }

            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic course(int userId, int courseId)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                dynamic user = new System.Dynamic.ExpandoObject();
                parameters.Add(new SqlParameter("@userId", userId > 0 ? userId : 0));
                parameters.Add(new SqlParameter("@courseId", courseId));

                DataSet ds = DbConnection.save("spGetParticularCourseDetails", parameters);
                

                if (ds.Tables[0].Rows.Count > 0)
                {
                    user.coursedetailId = (int?)ds.Tables[0].Rows[0]["coursedetailId"] ?? 0;
                    user.courseId = (int?)ds.Tables[0].Rows[0]["courseId"] ?? 0;
                    user.courseName = ds.Tables[0].Rows[0]["courseName"].ToString() ?? "";
                    user.courseDescription = ds.Tables[0].Rows[0]["courseDescription"].ToString() ?? "";
                    user.courseURL = ds.Tables[0].Rows[0]["courseURL"].ToString() ?? "";
                    user.courseType = ds.Tables[0].Rows[0]["courseType"].ToString() ?? "";
                    user.createdDate = ds.Tables[0].Rows[0]["createdDate"].ToString() ?? "";
                    user.isActive = (bool?)ds.Tables[0].Rows[0]["isActive"] ?? false;
                    user.paymentId = (int?)ds.Tables[0].Rows[0]["paymentId"] ?? 0;
                    user.truckDetails = ds.Tables[0].Rows[0]["truckDetails"].ToString() ?? "";
                    user.totalChapter = (int?)ds.Tables[0].Rows[0]["totalChapter"] ?? 0;
                    user.totalLesson = (int?)ds.Tables[0].Rows[0]["totalLesson"] ?? 0;
                    user.completedChapter = (int?)ds.Tables[0].Rows[0]["completedChapter"] ?? 0;
                    user.courseStartDate = ds.Tables[0].Rows[0]["courseStartDate"].ToString() ?? "";
                    user.status = ds.Tables[0].Rows[0]["status"].ToString() ?? "";
                    user.isChanged = (bool?)ds.Tables[0].Rows[0]["isChanged"] ?? false;



                    return new { status = "Success", data = user };
                }
                else
                {
                    return new { status = "Success", data = user, message = "No record found" };
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }
        public static dynamic takenChapter(int userId, int courseId)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@userId", userId > 0 ? userId : 0));
                parameters.Add(new SqlParameter("@courseId", courseId > 0 ? courseId : 0));
                dynamic course = new System.Dynamic.ExpandoObject();

                DataSet ds = DbConnection.save("spTakeChapter", parameters);
                
                if (ds.Tables[0].Rows.Count > 0)
                {
                    return new { status = "Success",chapterDetails= ds.Tables[0] };
                }
                else
                {
                    return new { status = "Success", data = ds.Tables[0], message = "No record found" };
                }

            }
            catch (Exception e)
            {
                throw e;
            }
        }
        public static dynamic takenLesson(int userId, int chapterId, int courseDetailId)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@userId", userId > 0 ? userId : 0));
                parameters.Add(new SqlParameter("@chapterId", chapterId > 0 ? chapterId : 0));
                parameters.Add(new SqlParameter("@courseDetailId", courseDetailId));

                dynamic course = new System.Dynamic.ExpandoObject();

                DataSet ds = DbConnection.save("spTakeLesson", parameters);

                if (ds.Tables[0].Rows.Count > 0)
                {
                    return new { status = "Success", chapterDetails = ds.Tables[0] };
                }
                else
                {
                    return new { status = "Success", data = ds.Tables[0], message = "No record found" };
                }

            }
            catch (Exception e)
            {
                throw e;
            }
        }
        public static dynamic takenMediaContent(int userId, int lessonId, int courseDetailId )
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@userId", userId > 0 ? userId : 0));
                parameters.Add(new SqlParameter("@lessonId", lessonId > 0 ? lessonId : 0));
                parameters.Add(new SqlParameter("@courseDetailId", courseDetailId));

                dynamic course = new System.Dynamic.ExpandoObject();

                DataSet ds = DbConnection.save("spTakeMediaContent", parameters);

                if (ds.Tables[0].Rows.Count > 0)
                {
                    return new { status = "Success", chapterDetails = ds.Tables[0] };
                }
                else
                {
                    return new { status = "Success", data = ds.Tables[0], message = "No record found" };
                }

            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic takenLessonforWeb(int userId, int courseId)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@userId", userId > 0 ? userId : 0));
                parameters.Add(new SqlParameter("@courseId", courseId > 0 ? courseId : 0));

                DataSet ds = DbConnection.save("spTakeChapterForWeb", parameters);
                dynamic course = new System.Dynamic.ExpandoObject();

                if (ds.Tables[0].Rows.Count > 0  & ds.Tables[1].Rows.Count > 0)
                {

                    course.courseId = (int?)ds.Tables[0].Rows[0]["courseId"] ?? 0;
                    course.courseName = ds.Tables[0].Rows[0]["courseName"].ToString() ?? "";
                    course.courseDescription = ds.Tables[0].Rows[0]["courseDescription"].ToString() ?? "";
                    course.courseURL = ds.Tables[0].Rows[0]["courseURL"].ToString() ?? "";
                    course.isActive = (bool?)ds.Tables[0].Rows[0]["isActive"] ?? false;
                    course.isFeatured = (bool?)ds.Tables[0].Rows[0]["isFeatured"] ?? false;
                    course.featuredStartDate = ds.Tables[0].Rows[0]["featuredStartDate"].ToString() ?? "";
                    course.featuredEndDate = ds.Tables[0].Rows[0]["featuredEndDate"].ToString() ?? "";
                    course.createdDate = ds.Tables[0].Rows[0]["createdDate"].ToString() ?? "";
                    course.truckDetails = ds.Tables[0].Rows[0]["truckDetails"].ToString() ?? "";
                    course.createdBy = (int?)ds.Tables[0].Rows[0]["createdBy"]?? 0;
                    course.createdName = ds.Tables[0].Rows[0]["createdName"].ToString() ?? "";
                    course.totalChapter = (int?)ds.Tables[0].Rows[0]["totalChapter"] ?? 0;
                    course.totalLesson = (int?)ds.Tables[0].Rows[0]["totalLesson"] ?? 0;
                    course.courseFee = (decimal?)ds.Tables[0].Rows[0]["courseFee"] ?? 0;
                    course.courseType = ds.Tables[0].Rows[0]["courseType"].ToString() ?? "";

                    return new { status = "Success", courseDetails = course, chapterDetails= ds.Tables[1] };
                }
                else
                {
                    return new { status = "Success", courseDetails = course, chapterDetails = ds.Tables[1], message = "No record found" };
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic userHistory(int userId)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                dynamic user = new System.Dynamic.ExpandoObject();
                parameters.Add(new SqlParameter("@userId", userId > 0 ? userId : 0));

                DataSet ds = DbConnection.save("spGetUserHistory", parameters);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    return new { status = "Success", data = ds.Tables[0] };
                }
                else
                {
                    return new { status = "Success", data = ds.Tables[0], message = "No record found" };
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic userMyHistory(int userId)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                dynamic user = new System.Dynamic.ExpandoObject();
                parameters.Add(new SqlParameter("@userId", userId > 0 ? userId : 0));

                DataSet ds = DbConnection.save("spGetMyCourse", parameters);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    return new { status = "Success", data = ds.Tables[0] };
                }
                else
                {
                    return new { status = "Success", data = ds.Tables[0], message = "No record found" };
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }
        public static dynamic userWishList(int userId)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                dynamic user = new System.Dynamic.ExpandoObject();
                parameters.Add(new SqlParameter("@userId", userId > 0 ? userId : 0));

                DataSet ds = DbConnection.save("spGetWisList", parameters);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    return new { status = "Success", data = ds.Tables[0] };
                }
                else
                {
                    return new { status = "Success", data = ds.Tables[0], message = "No record found" };
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic userWishListChapters(int userId, int courseId)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@userId", userId > 0 ? userId : 0));
                parameters.Add(new SqlParameter("@courseId", courseId > 0 ? courseId : 0));

                DataSet ds = DbConnection.save("spGetWisListChapter", parameters);

                if (ds.Tables[0].Rows.Count > 0 && ds.Tables[1].Rows.Count > 0)
                {

                    dynamic course = new System.Dynamic.ExpandoObject();
                    course.courseId = (int?)ds.Tables[0].Rows[0]["courseId"] ?? 0;
                    course.courseName = ds.Tables[0].Rows[0]["courseName"].ToString() ?? "";
                    course.courseDescription = ds.Tables[0].Rows[0]["courseDescription"].ToString() ?? "";
                    course.courseURL = ds.Tables[0].Rows[0]["courseURL"].ToString() ?? "";
                    course.totalChapter = (int?)ds.Tables[0].Rows[0]["totalChapter"] ?? 0;
                    course.totalLesson = (int?)ds.Tables[0].Rows[0]["totalLesson"] ?? 0;

                    return new { status = "Success", courseDetails = course, chapterDetails = ds.Tables[1] };
                }
                else
                {
                    return new { status = "Success", data = ds.Tables[0], message = "No record found" };
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }


        public static dynamic viewNotification(ViewNotification vn)
        {
            try
            {

                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@id", vn.id));
                parameters.Add(new SqlParameter("@userId", vn.userId));
                parameters.Add(new SqlParameter("@type", vn.type));

                DataTable dt = DbConnection.GetDataById("spViewnotification", parameters);
               
                if (dt.Rows[0]["errorMessage"].ToString() == "Success")
                {
                    return new { status = "Success", message = "Record saved successfully"};

                }
                else
                {
                    return new { status = "Error", message = dt.Rows[0]["errorMessage"].ToString() };
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }
    }
}
