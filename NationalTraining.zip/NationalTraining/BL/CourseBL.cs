﻿using NationalTraining.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace NationalTraining.BL
{
    public class CourseBL
    {

        public static dynamic createCourse(Course cr)
        {
            try
            {

                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@courseId", 0));
                parameters.Add(new SqlParameter("@courseName", cr.courseName));
                parameters.Add(new SqlParameter("@courseDescription", cr.courseDescription));
                parameters.Add(new SqlParameter("@createdBy", cr.createdBy));
                parameters.Add(new SqlParameter("@courseURL", cr.courseURL));
                parameters.Add(new SqlParameter("@isFeatured", cr.isFeatured));
                parameters.Add(new SqlParameter("@featuredStartDate", cr.featuredStartDate));
                parameters.Add(new SqlParameter("@featuredEndDate", cr.featuredEndDate));
                parameters.Add(new SqlParameter("@truckId", cr.truckId)); 
                parameters.Add(new SqlParameter("@isActive", cr.isActive));
                parameters.Add(new SqlParameter("@courseFee", cr.courseFee));
                parameters.Add(new SqlParameter("@courseType", cr.courseType));
                parameters.Add(new SqlParameter("@action", "Add"));

                DataTable dt = DbConnection.GetDataById("spSavecourse", parameters);
                int courseId = (int)dt.Rows[0]["courseId"];
                string message = dt.Rows[0]["errorMessage"].ToString();
                if (message == "Success")
                {
                    return new { status = message , courseId = courseId };
                }
                else if(message.Contains("UNIQUE KEY constraint") == true)
                {
                    return new { message = "Course name already exists", status = "Error" };
                }
                else
                {
                    return new { message = dt.Rows[0]["errorMessage"].ToString(), status = "Error" };

                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic updateCourse(UpdateCourse cr)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@courseId", cr.courseId));
                parameters.Add(new SqlParameter("@courseName", cr.courseName));
                parameters.Add(new SqlParameter("@courseDescription", cr.courseDescription));
                parameters.Add(new SqlParameter("@isFeatured", cr.isFeatured));
                parameters.Add(new SqlParameter("@featuredStartDate", cr.featuredStartDate));
                parameters.Add(new SqlParameter("@featuredEndDate", cr.featuredEndDate));
                parameters.Add(new SqlParameter("@isActive", cr.isActive));
                parameters.Add(new SqlParameter("@courseURL", cr.courseURL));
                parameters.Add(new SqlParameter("@truckId", cr.truckId));
                parameters.Add(new SqlParameter("@courseFee", cr.courseFee));
                parameters.Add(new SqlParameter("@courseType", cr.courseType));
                parameters.Add(new SqlParameter("@createdBy", cr.createdBy));
                parameters.Add(new SqlParameter("@action", "Edit"));

                DataTable dt = DbConnection.GetDataById("spSavecourse", parameters);
                int courseId = (int)dt.Rows[0]["courseId"];
                string message = dt.Rows[0]["errorMessage"].ToString();
                if (message == "Success")
                {
                    return new { status = message, courseId = courseId };
                }
                else if (message.Contains("UNIQUE KEY constraint") == true)
                {
                    return new { message = "Course name already exists", status = "Error" };
                }
                else
                {
                    return new { message = dt.Rows[0]["errorMessage"].ToString(), status = "Error" };
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }


        public static dynamic selectCourseById(int courseId)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                dynamic course = new System.Dynamic.ExpandoObject();
                parameters.Add(new SqlParameter("@courseId", courseId > 0 ? courseId : 0));
                DataTable dt = DbConnection.GetDataById("spSelectcourse", parameters);
                if (dt.Rows.Count > 0)
                {
                    course.courseId = (int?)dt.Rows[0]["courseId"] ?? 0;
                    course.courseName = dt.Rows[0]["courseName"].ToString() ?? "";
                    course.courseDescription = dt.Rows[0]["courseDescription"].ToString() ?? "";
                    course.createdDate = dt.Rows[0]["createdDate"].ToString() ?? "";
                    course.createdBy= (int?) dt.Rows[0]["createdBy"] ?? 0;
                    course.createdName = dt.Rows[0]["createdName"].ToString() ?? "";
                    course.courseURL = dt.Rows[0]["courseURL"].ToString() ?? ""; 
                    course.isFeatured = (bool?)dt.Rows[0]["isFeatured"] ?? false;
                    course.featuredStartDate = dt.Rows[0]["featuredStartDate"].ToString() ?? "";
                    course.featuredEndDate = dt.Rows[0]["featuredEndDate"].ToString() ?? "";
                    course.isActive = (bool?)dt.Rows[0]["isActive"] ?? false;
                    course.truckId = dt.Rows[0]["truckId"].ToString() ?? "";
                    course.truckDetails = dt.Rows[0]["truckDetails"].ToString() ?? "";
                    course.courseType = dt.Rows[0]["courseType"].ToString() ?? "";
                    course.courseFee =(decimal?) dt.Rows[0]["courseFee"] ?? 0;
                    course.isCourseWithoutChapter = (bool?)dt.Rows[0]["isCourseWithoutChapter"] ?? false;
                    course.isChapterWithoutLesson = (bool?)dt.Rows[0]["isChapterWithoutLesson"] ?? false;
                    course.isLessonWithoutContent = (bool?)dt.Rows[0]["isLessonWithoutContent"] ?? false;
                    course.isCourseWithoutTest = (bool?)dt.Rows[0]["isCourseWithoutTest"] ?? false;
                    course.isChapterWithoutTest = (bool?)dt.Rows[0]["isChapterWithoutTest"] ?? false;

                    course.isAllowDelete = (bool?)dt.Rows[0]["isAllowDelete"] ?? false;


                    return new { status = "Success", data = course };

                }
                else
                {
                    return new { status = "Success", data = course, message = "No record found" };

                }

            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic deleteCourse(int courseId)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@courseId", courseId));

                int result = DbConnection.Delete("spDeletecourse", parameters);
                if (result > 0)
                {
                    return new { status = "Success", message = "Record deleted successfully" };

                }
                else
                {
                    return new { status = "Error", message = "courseId not found" };
                }


            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static dynamic listCourse(int count, int offset, string courseName,string createdName)
        {
            List<dynamic> courseList = new List<dynamic>();
            try
            { 

                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@count", count > 0 ? count : 10));
                parameters.Add(new SqlParameter("@Offset", offset > 0 ? offset : 0)); 
                parameters.Add(new SqlParameter("@courseName", courseName));
                parameters.Add(new SqlParameter("@createdName", createdName));

                DataSet ds = DbConnection.save("spGetcourse", parameters);
                DataTable dt = ds.Tables[1];
                DataTable dt1 = ds.Tables[0];

                if (dt.Rows.Count > 0)
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        dynamic courseobj = new System.Dynamic.ExpandoObject();
                        courseobj.courseId = (int?)dt.Rows[i]["courseId"] ?? 0;
                        courseobj.courseName = dt.Rows[i]["courseName"].ToString() ?? "";
                        courseobj.createdDate = dt.Rows[i]["createdDate"].ToString() ?? "";
                        courseobj.createdBy = (int?)dt.Rows[i]["createdBy"] ?? 0;
                        courseobj.createdName = dt.Rows[i]["createdName"].ToString() ?? "";
                        courseobj.courseURL = dt.Rows[i]["courseURL"].ToString() ?? "";
                        courseobj.courseDescription = dt.Rows[i]["courseDescription"].ToString() ?? ""; 
                        courseobj.isFeatured = (bool?)dt.Rows[i]["isFeatured"] ?? false;
                        courseobj.featuredStartDate = dt.Rows[i]["featuredStartDate"].ToString() ?? "";
                        courseobj.featuredEndDate = dt.Rows[i]["featuredEndDate"].ToString() ?? "";
                        courseobj.isActive = (bool?)dt.Rows[i]["isActive"] ?? false;
                        courseobj.truckDetails = dt.Rows[i]["truckDetails"].ToString();
                        courseobj.truckId = dt.Rows[i]["truckId"].ToString();
                        courseobj.courseFee = (decimal?)dt.Rows[i]["courseFee"]??0;
                        courseobj.courseType = dt.Rows[i]["courseType"].ToString() ?? "0"; 
                        courseobj.truckDetails = dt.Rows[i]["truckDetails"].ToString();
                        courseobj.isAllowDelete = (bool?)dt.Rows[i]["isAllowDelete"] ?? false;

                        courseList.Add(courseobj);
                    }
                    return new { status = "Success", data = ds.Tables[1], count = (int?)dt1.Rows[0][0] ?? 0 };

                }
                else
                {
                    return new { status = "Success", data = courseList, message = "No record found" };

                }

            }

            catch (Exception e)
            {
                throw e;
            }
        }

      

        public static dynamic getCourseReport(int count, int offset, string courseName, string email, string firstName, string lastName, string phone,
          string courseStatus,string testStatus, int courseId, int userId, string courseType)
        {
              try
            {

                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@count", count > 0 ? count : 10));
                parameters.Add(new SqlParameter("@Offset", offset > 0 ? offset : 0));
                parameters.Add(new SqlParameter("@courseName", courseName));
                parameters.Add(new SqlParameter("@email", email));
                parameters.Add(new SqlParameter("@firstName", firstName));
                parameters.Add(new SqlParameter("@lastName", lastName));
                parameters.Add(new SqlParameter("@phone", phone));
                parameters.Add(new SqlParameter("@courseStatus", courseStatus));
                parameters.Add(new SqlParameter("@testStatus", testStatus));
                parameters.Add(new SqlParameter("@courseId", courseId));
                parameters.Add(new SqlParameter("@userId", userId));
                parameters.Add(new SqlParameter("@courseType", courseType));


                DataSet ds = DbConnection.save("spGetCourseReport", parameters);
                DataTable dt = ds.Tables[1];
                DataTable dt1 = ds.Tables[0];

                if (dt.Rows.Count > 0)
                {

                    return new { status = "Success", data = dt, count = (int?)dt1.Rows[0][0] ?? 0 };

                }
                else
                {
                    return new { status = "Success", data = dt, message = "No record found" };

                }

            }

            catch (Exception e)
            {
                throw e;
            }
        }



    }

}
