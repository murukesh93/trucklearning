﻿using Stripe;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using NationalTraining.Data;
using NationalTraining.Models;

namespace NationalTraining.BL
{
    public class StripeBL
    {

        #region addCustomer

        public static string addCustomer(string name, string phone, string email)
        {
            try
            {
                //StripeConfiguration.ApiKey = "sk_test_ijuEZbZ1t0Tojmpsu7QOxqmz";
                StripeConfiguration.ApiKey = Common.GetConnectionString("Stripe", "Secretkey");

                //Stripe.AddressOptions obj = new AddressOptions();
                //obj.City = "Chennai";
                //obj.Line1 = "377 East street ";
                //obj.Country = "India";
                //obj.State = "TamilNadu";
                //obj.PostalCode = "626010";
                var options = new CustomerCreateOptions
                {
                    Balance = 0,
                    Name = name,
                    Phone = phone,
                    Email = email,
                    //Address = obj,
                    //Description = "Customer for chitras@apptomate.co"
                };
                var service = new CustomerService();
                var response = service.Create(options);

                //HttpClient client = new HttpClient();
                //client.DefaultRequestHeaders.Add("Authorization", "Bearer sk_test_d41QBmBw0QFBshVWjhPR3JYG00I3TWMgA0");
                //var a =  await client.PostAsJsonAsync("https://api.stripe.com/v1/customers", options);


                return response.Id;

            }
            catch (Exception e)
            {
                throw e;
            }
        }
        #endregion

        #region addCard

        public Card addCard(addCard objcard)
        {
            try
            {

                StripeConfiguration.ApiKey = Common.GetConnectionString("Stripe", "Secretkey");

                var options = new CardCreateOptions
                {
                    Source = objcard.token,
                    
                };
                var service = new CardService();
                var response = service.Create(objcard.customerId, options);  

                return response;

            }
            catch (Exception e)
            {

                throw e;
            }
        }
        #endregion

        #region updateCustomer

        public static Customer updateCustomer(updateCustomer objcard)
        {
            try
            {
                StripeConfiguration.ApiKey = Common.GetConnectionString("Stripe", "Secretkey");

                var options = new CustomerUpdateOptions
                {
                    DefaultSource = objcard.cardId,
                };
                var service = new CustomerService();
                var response = service.Update(objcard.customerId, options);

                return response;

            }
            catch (Exception e)
            {

                throw e;
            }
        }
        #endregion 

        #region deleteCard 
        public Card deleteCard(updateCustomer customer)
        {
            try
            {
                StripeConfiguration.ApiKey = Common.GetConnectionString("Stripe", "Secretkey");

                var service = new CardService();
                var cards = service.Delete(
                  customer.customerId,
                  customer.cardId
                );

                return cards ;

            }
            catch (Exception e)
            {

                throw e;
            }
        }
        #endregion  

        #region listCardByUserId
       
        public static StripeList<Card> listCardByUserId(string customerId)
        {
            try
            {
               
                StripeConfiguration.ApiKey = Common.GetConnectionString("Stripe", "Secretkey");

                var service = new CardService();
                var options = new CardListOptions
                {
                    Limit = 10,
                };
                var cards = service.List(customerId, options);

                return  cards;

            }
            catch (Exception e)
            {

                throw e;
            }
        }
        #endregion
         
        #region paymentMethod
        public  static Charge paymentMethod( Payment payment)
        {
            try
            {
                StripeConfiguration.ApiKey = Common.GetConnectionString("Stripe", "Secretkey");
              
                var charges = new ChargeService();
                var charge = charges.Create(new ChargeCreateOptions
                {
                    Amount = Convert.ToInt64(payment.amount * 100),
                    Description = payment.description,
                    Currency = "usd",
                    Customer = payment.customerId,
                    Source = payment.source
                });
                return charge;
            }
            catch (Exception e)
            {
                throw e;
            }
        }
        #endregion

        #region paymentHistory
            public  Charge paymentHistory(string chargeId)
            {
                try
                {
                    StripeConfiguration.ApiKey = Common.GetConnectionString("Stripe", "Secretkey");

                    var service = new ChargeService();
                    var result =   service.Get(chargeId);
              

                    return result;
                }
                catch (Exception e)
                {

                    throw e;
                }
            }
        #endregion

        #region retrieveCustomer

        public static Customer retrieveCustomer(StripeCustomer stripe)
        {
            try
            {

                StripeConfiguration.ApiKey = Common.GetConnectionString("Stripe", "Secretkey");

                var service = new CustomerService();
                var response = service.Get(stripe.customerId);
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@customerId", stripe.customerId));

                //DataTable dt = DbConnection.GetDataById("spWalletBalance", parameters);

                //decimal amount = (decimal)dt.Rows[0][0];
                //return new { response, walletAmount = amount };
                return response;

            }
            catch (Exception e)
            {

                throw e;
            }
        }
        #endregion

        public dynamic purchaseCourse(PurchaseCourse pc)
        {
            try
            {
               
                    var amnt = Convert.ToDouble(pc.amount);
                    Payment objPayment = new Payment();
                    objPayment.customerId = pc.customerId;
                    objPayment.amount = Math.Round(amnt + (((amnt * 0.029) + 0.3) / 0.971), 2);  // including stripe charge
                    objPayment.description = "Purchase Course";
                    objPayment.source = pc.source;

                    var paymentResult = StripeBL.paymentMethod(objPayment);

                    if (paymentResult.Status == "succeeded")
                    {
                        // payment success log 
                        var apidata = new { amount = pc.amount, Id = paymentResult.Id, Description = objPayment.description, paymentResult = paymentResult };
                        Common.SaveAPILog("purchaseCourse", apidata.ToString(), pc.userId);
                     
                  

                        List<SqlParameter> parameters = new List<SqlParameter>();
                        parameters.Add(new SqlParameter("@userId", pc.userId));
                        parameters.Add(new SqlParameter("@courseId", pc.courseId));
                        parameters.Add(new SqlParameter("@amount", pc.amount));
                        parameters.Add(new SqlParameter("@bankTransactionID", paymentResult.Id));
                        parameters.Add(new SqlParameter("@paymentResponse", paymentResult.ToString()));
                       parameters.Add(new SqlParameter("@customerCardId", paymentResult.PaymentMethod));

                        DataTable dt = DbConnection.GetDataById("spSavePaymentDetails", parameters);

                        string result = dt.Rows[0][0].ToString();

                      return new { status = "Success", message = "Course purchased successfully." }; ;
                    }
                    else
                    {

                    return new { status = "Error", message = "Error in purchase course." };
                }
               

            }
            catch (Exception e)
            {
                throw e;
            }
        }


    }
}
